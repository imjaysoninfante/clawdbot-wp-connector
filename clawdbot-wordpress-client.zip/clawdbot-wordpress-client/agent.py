"""
agent.py
========

A complete "clawdbot" agent loop: it connects to your WordPress site through the
Claude WP Connector plugin and lets Claude operate the site with natural-language
instructions.

How it works
------------
1. Connects to your WordPress MCP endpoint (via wp_mcp_client.WPMCPClient).
2. Fetches the site's tool definitions and converts them into Anthropic
   tool-use format.
3. Runs an agent loop: sends your instruction to Claude, executes any tool calls
   against WordPress, feeds results back, and repeats until Claude is done.

Setup
-----
    pip install -r requirements.txt

    export ANTHROPIC_API_KEY="sk-ant-..."
    export WP_MCP_ENDPOINT="https://yoursite.com/wp-json/claude-connector/v1/mcp"
    export WP_MCP_TOKEN="your-plugin-bearer-token"

Run
---
    # One-shot instruction:
    python agent.py "List my 5 newest posts and tell me which are still drafts."

    # Interactive chat:
    python agent.py
"""

from __future__ import annotations

import os
import sys
import json
from typing import Any, Dict, List

import anthropic

from wp_mcp_client import WPMCPClient, WPMCPError

MODEL = os.environ.get("CLAWDBOT_MODEL", "claude-sonnet-5")
MAX_TURNS = int(os.environ.get("CLAWDBOT_MAX_TURNS", "20"))

SYSTEM_PROMPT = (
    "You are clawdbot, an assistant that manages a WordPress website through a "
    "set of tools. Work carefully and make the smallest change that satisfies "
    "the request. Before editing page-builder content (Elementor, Divi, Beaver), "
    "read it first with cwpc_get_builder_content so you edit the correct data. "
    "When creating content, default to draft status unless told to publish. "
    "Summarize what you changed, including post IDs and links."
)


def to_anthropic_tools(mcp_tools: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Convert MCP tool defs -> Anthropic tool-use schema."""
    tools = []
    for t in mcp_tools:
        tools.append(
            {
                "name": t["name"],
                "description": t.get("description", ""),
                "input_schema": t.get("inputSchema", {"type": "object", "properties": {}}),
            }
        )
    return tools


def run_tool(wp: WPMCPClient, name: str, args: Dict[str, Any]) -> str:
    """Execute one WordPress tool and return a string result for Claude."""
    try:
        result = wp.call_tool(name, args)
        return result if isinstance(result, str) else json.dumps(result, indent=2)
    except WPMCPError as exc:
        return f"ERROR: {exc}"


def agent_turn(client: anthropic.Anthropic, wp: WPMCPClient,
               tools: List[Dict[str, Any]], messages: List[Dict[str, Any]]) -> str:
    """Run the tool-use loop until Claude produces a final text answer."""
    for _ in range(MAX_TURNS):
        response = client.messages.create(
            model=MODEL,
            max_tokens=4096,
            system=SYSTEM_PROMPT,
            tools=tools,
            messages=messages,
        )

        messages.append({"role": "assistant", "content": response.content})

        if response.stop_reason != "tool_use":
            # Final answer: gather any text blocks.
            return "".join(
                block.text for block in response.content if block.type == "text"
            ).strip()

        # Execute every tool call in this turn.
        tool_results = []
        for block in response.content:
            if block.type == "tool_use":
                print(f"  -> {block.name}({json.dumps(block.input)})")
                output = run_tool(wp, block.name, block.input)
                tool_results.append(
                    {
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": output,
                    }
                )
        messages.append({"role": "user", "content": tool_results})

    return "(Stopped: reached the maximum number of tool turns.)"


def main() -> None:
    endpoint = os.environ.get("WP_MCP_ENDPOINT")
    token = os.environ.get("WP_MCP_TOKEN")
    if not endpoint:
        sys.exit("Set WP_MCP_ENDPOINT (and WP_MCP_TOKEN) first.")
    if not os.environ.get("ANTHROPIC_API_KEY"):
        sys.exit("Set ANTHROPIC_API_KEY first.")

    wp = WPMCPClient(endpoint=endpoint, token=token)
    wp.initialize()
    mcp_tools = wp.list_tools()
    tools = to_anthropic_tools(mcp_tools)
    print(f"Connected to WordPress. {len(tools)} tools available.\n")

    client = anthropic.Anthropic()
    messages: List[Dict[str, Any]] = []

    # One-shot mode: instruction passed as CLI args.
    if len(sys.argv) > 1:
        instruction = " ".join(sys.argv[1:])
        messages.append({"role": "user", "content": instruction})
        print(agent_turn(client, wp, tools, messages))
        return

    # Interactive mode.
    print("clawdbot ready. Type an instruction, or 'quit' to exit.\n")
    while True:
        try:
            user = input("you> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if user.lower() in {"quit", "exit"}:
            break
        if not user:
            continue
        messages.append({"role": "user", "content": user})
        answer = agent_turn(client, wp, tools, messages)
        print(f"\nclawdbot> {answer}\n")


if __name__ == "__main__":
    main()
