"""
wp_mcp_client.py
================

A tiny, dependency-light client for the Claude WP Connector MCP endpoint.

Your own agent ("clawdbot") uses this to talk directly to your WordPress site
over MCP JSON-RPC. No bridge process is required — this speaks HTTP straight to
the plugin's /mcp endpoint using your bearer token.

Usage
-----
    from wp_mcp_client import WPMCPClient

    wp = WPMCPClient(
        endpoint="https://yoursite.com/wp-json/claude-connector/v1/mcp",
        token="YOUR_BEARER_TOKEN",
    )
    wp.initialize()
    print(wp.list_tools())                       # discover capabilities
    print(wp.call_tool("cwpc_site_info", {}))    # run one
    print(wp.call_tool("cwpc_list_posts", {"per_page": 5}))

Only requires the `requests` package.
"""

from __future__ import annotations

import json
import itertools
from typing import Any, Dict, List, Optional

import requests


class WPMCPError(RuntimeError):
    """Raised when the MCP server returns a JSON-RPC error or a tool fails."""


class WPMCPClient:
    """Minimal synchronous MCP client for the Claude WP Connector plugin."""

    PROTOCOL_VERSION = "2024-11-05"

    def __init__(
        self,
        endpoint: str,
        token: Optional[str] = None,
        *,
        basic_auth: Optional[tuple] = None,
        timeout: int = 60,
    ) -> None:
        """
        endpoint   : full URL to .../claude-connector/v1/mcp
        token      : plugin bearer token (Settings -> Claude Connector)
        basic_auth : alternatively, (username, application_password) tuple
        """
        self.endpoint = endpoint.rstrip("/")
        self.timeout = timeout
        self._ids = itertools.count(1)
        self._initialized = False

        self._session = requests.Session()
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if token:
            headers["Authorization"] = f"Bearer {token}"
        self._session.headers.update(headers)

        if basic_auth:
            self._session.auth = basic_auth  # (user, application_password)

    # ------------------------------------------------------------------ #
    #  Low-level JSON-RPC                                                 #
    # ------------------------------------------------------------------ #

    def _rpc(self, method: str, params: Optional[Dict[str, Any]] = None,
             *, notification: bool = False) -> Any:
        payload: Dict[str, Any] = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            payload["params"] = params
        if not notification:
            payload["id"] = next(self._ids)

        resp = self._session.post(self.endpoint, data=json.dumps(payload),
                                  timeout=self.timeout)

        if resp.status_code == 401:
            raise WPMCPError("Unauthorized (401): check your token or application password.")
        if resp.status_code == 404:
            raise WPMCPError("Endpoint not found (404): verify the /mcp URL and that the plugin is active.")

        if notification:
            return None

        try:
            data = resp.json()
        except ValueError:
            raise WPMCPError(f"Non-JSON response ({resp.status_code}): {resp.text[:300]}")

        if isinstance(data, dict) and data.get("error"):
            err = data["error"]
            raise WPMCPError(f"JSON-RPC error {err.get('code')}: {err.get('message')}")

        return data.get("result") if isinstance(data, dict) else data

    # ------------------------------------------------------------------ #
    #  MCP handshake + tools                                             #
    # ------------------------------------------------------------------ #

    def initialize(self) -> Dict[str, Any]:
        """Perform the MCP handshake. Safe to call once before other calls."""
        result = self._rpc(
            "initialize",
            {
                "protocolVersion": self.PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "clawdbot", "version": "1.0.0"},
            },
        )
        # Tell the server we're ready (notification, no response expected).
        self._rpc("notifications/initialized", {}, notification=True)
        self._initialized = True
        return result

    def _ensure_ready(self) -> None:
        if not self._initialized:
            self.initialize()

    def list_tools(self) -> List[Dict[str, Any]]:
        """Return the list of tool definitions the site exposes."""
        self._ensure_ready()
        result = self._rpc("tools/list", {})
        return result.get("tools", []) if isinstance(result, dict) else []

    def call_tool(self, name: str, arguments: Optional[Dict[str, Any]] = None) -> Any:
        """
        Call a WordPress tool. Returns the parsed result (dict/list) when the
        tool returned JSON, else the raw text. Raises WPMCPError if the tool
        reported an error.
        """
        self._ensure_ready()
        result = self._rpc("tools/call", {"name": name, "arguments": arguments or {}})

        content = (result or {}).get("content", [])
        text = ""
        if content and isinstance(content, list):
            text = content[0].get("text", "")

        if (result or {}).get("isError"):
            raise WPMCPError(text or f"Tool '{name}' failed.")

        # Try to parse JSON payloads back into Python objects.
        try:
            return json.loads(text)
        except (ValueError, TypeError):
            return text

    def ping(self) -> bool:
        """Return True if the server answers the MCP ping."""
        self._ensure_ready()
        self._rpc("ping", {})
        return True


if __name__ == "__main__":
    import os

    client = WPMCPClient(
        endpoint=os.environ["WP_MCP_ENDPOINT"],
        token=os.environ.get("WP_MCP_TOKEN"),
    )
    client.initialize()
    print("Connected. Tools available:")
    for t in client.list_tools():
        print(f"  - {t['name']}: {t.get('description','')[:70]}")
    print("\nSite info:")
    print(json.dumps(client.call_tool("cwpc_site_info", {}), indent=2))
