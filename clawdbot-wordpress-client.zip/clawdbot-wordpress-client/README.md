# Clawdbot → WordPress client

Connect **your own Claude agent ("clawdbot")** to your WordPress site through the
Claude WP Connector plugin. Your agent talks MCP JSON-RPC directly to the
plugin's `/mcp` endpoint over HTTPS — no bridge process needed (the `mcp-remote`
bridge is only required for Claude Desktop, which needs stdio).

## Files

| File | What it is |
|------|-----------|
| `wp_mcp_client.py` | A small, reusable MCP client. Drop it into your agent to call any WordPress tool. |
| `agent.py` | A complete example agent loop: gives Claude the WordPress tools and executes what it decides to do. |
| `requirements.txt` | `requests` + `anthropic`. |

## Prerequisites

1. The **Claude WP Connector** plugin installed and active on your site.
2. From **Settings → Claude Connector**: your **MCP endpoint URL** and **bearer token**.

## Setup

```bash
pip install -r requirements.txt

export ANTHROPIC_API_KEY="sk-ant-..."
export WP_MCP_ENDPOINT="https://yoursite.com/wp-json/claude-connector/v1/mcp"
export WP_MCP_TOKEN="your-plugin-bearer-token"
```

## Quick test (client only, no AI)

```bash
python wp_mcp_client.py
```

Prints the available tools and your site info — confirms the connection works.

## Run the agent

```bash
# one-shot
python agent.py "Create a draft page called 'Services' with three sections."

# interactive
python agent.py
```

## Use the client inside your existing agent

If you already have a clawdbot, you only need `wp_mcp_client.py`:

```python
from wp_mcp_client import WPMCPClient

wp = WPMCPClient(endpoint=WP_MCP_ENDPOINT, token=WP_MCP_TOKEN)
wp.initialize()

# Discover what the site can do:
tools = wp.list_tools()

# Do things:
wp.call_tool("cwpc_create_post", {"title": "Hello", "status": "draft"})
wp.call_tool("cwpc_get_builder_content", {"id": 42})
```

To let Claude drive it, convert `tools` to Anthropic tool-use format — see
`to_anthropic_tools()` in `agent.py`. The same conversion works for any
MCP-aware framework (OpenAI tool calling, LangChain, etc.); only the schema key
names differ.

## Auth alternatives

- **Bearer token** (default): pass `token=...`.
- **Application Password**: `WPMCPClient(endpoint=..., basic_auth=("username", "app password"))`.

## Notes

- All calls are capability-checked server-side; your agent can never exceed the
  WordPress user it authenticates as.
- Read builder content before editing it so you send back the right shape
  (Elementor/Beaver = JSON in `data`; Divi/Gutenberg/classic = HTML in `content`).
- Regenerating the token in plugin settings instantly revokes an agent's access.
