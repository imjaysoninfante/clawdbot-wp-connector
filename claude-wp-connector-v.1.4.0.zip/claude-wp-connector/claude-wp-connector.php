<?php
/**
 * Plugin Name:       Claude WP Connector
 * Plugin URI:        https://example.com/claude-wp-connector
 * Description:        Exposes your WordPress site to Claude (and any MCP client) with administrator-level control: posts, pages, media, taxonomies, and page builders (Elementor, Divi, Beaver Builder). Secured with a bearer token or WordPress Application Passwords.
 * Version:           1.4.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Jayson
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       claude-wp-connector
 *
 * SECURITY NOTE: This plugin grants a connected AI client the same power as a
 * WordPress administrator. Keep the token secret, serve your site over HTTPS,
 * and remove the plugin if you stop using it.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'CWPC_VERSION', '1.4.0' );
define( 'CWPC_PLUGIN_FILE', __FILE__ );
define( 'CWPC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CWPC_NAMESPACE', 'claude-connector/v1' );

require_once CWPC_PLUGIN_DIR . 'includes/class-cwpc-auth.php';
require_once CWPC_PLUGIN_DIR . 'includes/class-cwpc-tools.php';
require_once CWPC_PLUGIN_DIR . 'includes/class-cwpc-mcp-server.php';

/**
 * Main plugin controller.
 */
final class CWPC_Plugin {

	/** @var CWPC_Plugin */
	private static $instance;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	/**
	 * Register the MCP endpoint and a simple health-check route.
	 */
	public function register_routes() {
		$server = new CWPC_MCP_Server();

		// Primary MCP (JSON-RPC) endpoint.
		register_rest_route(
			CWPC_NAMESPACE,
			'/mcp',
			array(
				'methods'             => 'POST',
				'callback'            => array( $server, 'handle' ),
				'permission_callback' => array( 'CWPC_Auth', 'check' ),
			)
		);

		// Unauthenticated health check so you can confirm the plugin is live.
		register_rest_route(
			CWPC_NAMESPACE,
			'/ping',
			array(
				'methods'             => 'GET',
				'callback'            => function () {
					return array(
						'ok'      => true,
						'plugin'  => 'Claude WP Connector',
						'version' => CWPC_VERSION,
						'site'    => get_bloginfo( 'name' ),
					);
				},
				'permission_callback' => '__return_true',
			)
		);
	}

	/* ------------------------------------------------------------------ */
	/*  Admin settings page                                               */
	/* ------------------------------------------------------------------ */

	public function admin_menu() {
		add_options_page(
			__( 'Claude WP Connector', 'claude-wp-connector' ),
			__( 'Claude Connector', 'claude-wp-connector' ),
			'manage_options',
			'claude-wp-connector',
			array( $this, 'render_settings_page' )
		);
	}

	public function register_settings() {
		register_setting( 'cwpc_settings', 'cwpc_token', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting(
			'cwpc_settings',
			'cwpc_admin_user',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 0,
			)
		);
		register_setting(
			'cwpc_settings',
			'cwpc_allow_dangerous',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 0,
			)
		);
	}

	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Generate a token on demand.
		if ( isset( $_POST['cwpc_generate_token'] ) && check_admin_referer( 'cwpc_generate_token' ) ) {
			update_option( 'cwpc_token', wp_generate_password( 48, false, false ) );
			echo '<div class="notice notice-success"><p>' . esc_html__( 'A new token was generated.', 'claude-wp-connector' ) . '</p></div>';
		}

		$token      = get_option( 'cwpc_token', '' );
		$admin_user = (int) get_option( 'cwpc_admin_user', get_current_user_id() );
		$endpoint   = rest_url( CWPC_NAMESPACE . '/mcp' );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Claude WP Connector', 'claude-wp-connector' ); ?></h1>
			<p><?php esc_html_e( 'Connect this site to Claude (or any MCP client) with administrator-level control.', 'claude-wp-connector' ); ?></p>

			<h2><?php esc_html_e( 'Your connection details', 'claude-wp-connector' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'MCP endpoint URL', 'claude-wp-connector' ); ?></th>
					<td><code><?php echo esc_html( $endpoint ); ?></code></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Bearer token', 'claude-wp-connector' ); ?></th>
					<td>
						<code style="word-break:break-all;"><?php echo $token ? esc_html( $token ) : esc_html__( '(none yet - generate one below)', 'claude-wp-connector' ); ?></code>
						<form method="post" style="margin-top:8px;">
							<?php wp_nonce_field( 'cwpc_generate_token' ); ?>
							<button type="submit" name="cwpc_generate_token" class="button button-secondary">
								<?php echo $token ? esc_html__( 'Regenerate token', 'claude-wp-connector' ) : esc_html__( 'Generate token', 'claude-wp-connector' ); ?>
							</button>
						</form>
						<p class="description"><?php esc_html_e( 'Send this as an HTTP header "Authorization: Bearer <token>" or as a ?token= query parameter.', 'claude-wp-connector' ); ?></p>
					</td>
				</tr>
			</table>

			<form method="post" action="options.php">
				<?php settings_fields( 'cwpc_settings' ); ?>
				<h2><?php esc_html_e( 'Settings', 'claude-wp-connector' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="cwpc_admin_user"><?php esc_html_e( 'Act as user', 'claude-wp-connector' ); ?></label></th>
						<td>
							<?php
							wp_dropdown_users(
								array(
									'name'     => 'cwpc_admin_user',
									'id'       => 'cwpc_admin_user',
									'selected' => $admin_user,
									'role'     => 'administrator',
								)
							);
							?>
							<p class="description"><?php esc_html_e( 'When a request authenticates with the bearer token, the plugin acts as this administrator.', 'claude-wp-connector' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Enable dangerous tools', 'claude-wp-connector' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="cwpc_allow_dangerous" value="1" <?php checked( 1, (int) get_option( 'cwpc_allow_dangerous', 0 ) ); ?> />
								<?php esc_html_e( 'Allow user management, plugin activation/deactivation, and option editing.', 'claude-wp-connector' ); ?>
							</label>
							<p class="description"><?php esc_html_e( 'Leave off unless you need it. Content and page-builder tools work regardless.', 'claude-wp-connector' ); ?></p>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}

CWPC_Plugin::instance();
