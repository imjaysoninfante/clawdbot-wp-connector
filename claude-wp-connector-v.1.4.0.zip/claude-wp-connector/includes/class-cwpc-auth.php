<?php
/**
 * Authentication for the Claude WP Connector MCP endpoint.
 *
 * Two supported paths:
 *   1. WordPress Application Password (standard Basic auth). If WordPress has
 *      already authenticated the request as a user who can manage_options,
 *      we allow it.
 *   2. Plugin bearer token. Sent as "Authorization: Bearer <token>" or as a
 *      "?token=<token>" query parameter. On success we act as the configured
 *      administrator so capability checks behave correctly.
 *
 * @package Claude_WP_Connector
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CWPC_Auth {

	/**
	 * REST permission_callback for the MCP endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return bool|WP_Error
	 */
	public static function check( $request ) {
		// Path 1: already authenticated via Application Password / cookie.
		if ( is_user_logged_in() && current_user_can( 'manage_options' ) ) {
			return true;
		}

		// Path 2: plugin bearer token.
		$provided = self::extract_token( $request );
		$expected = (string) get_option( 'cwpc_token', '' );

		if ( '' !== $expected && '' !== $provided && hash_equals( $expected, $provided ) ) {
			$admin_id = (int) get_option( 'cwpc_admin_user', 0 );

			if ( ! $admin_id ) {
				// Fall back to the first administrator on the site.
				$admins   = get_users(
					array(
						'role'   => 'administrator',
						'number' => 1,
						'fields' => 'ID',
					)
				);
				$admin_id = $admins ? (int) $admins[0] : 0;
			}

			if ( $admin_id && user_can( $admin_id, 'manage_options' ) ) {
				wp_set_current_user( $admin_id );
				return true;
			}

			return new WP_Error(
				'cwpc_no_admin',
				__( 'Token is valid but no administrator is configured to act as.', 'claude-wp-connector' ),
				array( 'status' => 500 )
			);
		}

		return new WP_Error(
			'cwpc_unauthorized',
			__( 'Missing or invalid credentials.', 'claude-wp-connector' ),
			array( 'status' => 401 )
		);
	}

	/**
	 * Pull the bearer token from the request headers or query string.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return string
	 */
	private static function extract_token( $request ) {
		// Authorization: Bearer <token>
		$header = $request->get_header( 'authorization' );
		if ( ! $header && isset( $_SERVER['HTTP_AUTHORIZATION'] ) ) {
			$header = wp_unslash( $_SERVER['HTTP_AUTHORIZATION'] );
		}
		if ( $header && preg_match( '/Bearer\s+(.+)/i', $header, $m ) ) {
			return trim( $m[1] );
		}

		// Custom header, useful for clients that reserve Authorization.
		$custom = $request->get_header( 'x-cwpc-token' );
		if ( $custom ) {
			return trim( $custom );
		}

		// ?token= query parameter.
		$query = $request->get_param( 'token' );
		if ( $query ) {
			return trim( $query );
		}

		return '';
	}
}
