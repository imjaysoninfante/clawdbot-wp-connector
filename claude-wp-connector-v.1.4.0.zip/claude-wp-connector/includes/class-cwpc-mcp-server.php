<?php
/**
 * Minimal Model Context Protocol (MCP) server over HTTP JSON-RPC 2.0.
 *
 * Implements the handshake and tool methods used by MCP clients such as
 * Claude: initialize, notifications/initialized, ping, tools/list, tools/call.
 *
 * Transport: a single POST endpoint that accepts one JSON-RPC request (or a
 * batch array) and returns a JSON-RPC response. This is compatible with the
 * "Streamable HTTP" transport when used through a bridge such as mcp-remote.
 *
 * @package Claude_WP_Connector
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CWPC_MCP_Server {

	const PROTOCOL_VERSION = '2024-11-05';

	/** @var CWPC_Tools */
	private $tools;

	public function __construct() {
		$this->tools = new CWPC_Tools();
	}

	/**
	 * REST callback. Reads the raw JSON-RPC body and dispatches it.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function handle( $request ) {
		$body = $request->get_json_params();

		if ( null === $body ) {
			$raw  = $request->get_body();
			$body = json_decode( $raw, true );
		}

		if ( ! is_array( $body ) ) {
			return $this->rest( $this->error( null, -32700, 'Parse error' ) );
		}

		// Batch request.
		if ( array_key_exists( 0, $body ) ) {
			$responses = array();
			foreach ( $body as $single ) {
				$resp = $this->dispatch( $single );
				if ( null !== $resp ) {
					$responses[] = $resp;
				}
			}
			return $this->rest( empty( $responses ) ? null : $responses );
		}

		$resp = $this->dispatch( $body );
		return $this->rest( $resp );
	}

	/**
	 * Dispatch a single JSON-RPC message.
	 *
	 * @param array $msg Message.
	 * @return array|null Response, or null for notifications.
	 */
	private function dispatch( $msg ) {
		$id     = isset( $msg['id'] ) ? $msg['id'] : null;
		$method = isset( $msg['method'] ) ? $msg['method'] : '';
		$params = isset( $msg['params'] ) && is_array( $msg['params'] ) ? $msg['params'] : array();

		// Notifications (no id) get no response.
		$is_notification = ! array_key_exists( 'id', $msg );

		switch ( $method ) {
			case 'initialize':
				return $this->result(
					$id,
					array(
						'protocolVersion' => self::PROTOCOL_VERSION,
						'capabilities'    => array(
							'tools' => array( 'listChanged' => false ),
						),
						'serverInfo'      => array(
							'name'    => 'claude-wp-connector',
							'version' => CWPC_VERSION,
						),
					)
				);

			case 'notifications/initialized':
			case 'notifications/cancelled':
				return null; // Acknowledge silently.

			case 'ping':
				return $this->result( $id, new stdClass() );

			case 'tools/list':
				return $this->result( $id, array( 'tools' => $this->tools->definitions() ) );

			case 'tools/call':
				$name = isset( $params['name'] ) ? $params['name'] : '';
				$args = isset( $params['arguments'] ) && is_array( $params['arguments'] ) ? $params['arguments'] : array();

				try {
					$output = $this->tools->call( $name, $args );

					if ( is_wp_error( $output ) ) {
						return $this->tool_error( $id, $output->get_error_message() );
					}

					return $this->result(
						$id,
						array(
							'content' => array(
								array(
									'type' => 'text',
									'text' => is_string( $output ) ? $output : wp_json_encode( $output, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ),
								),
							),
							'isError' => false,
						)
					);
				} catch ( Exception $e ) {
					return $this->tool_error( $id, $e->getMessage() );
				}

			default:
				if ( $is_notification ) {
					return null;
				}
				return $this->error( $id, -32601, 'Method not found: ' . $method );
		}
	}

	/* ------------------------------------------------------------------ */
	/*  JSON-RPC helpers                                                  */
	/* ------------------------------------------------------------------ */

	private function result( $id, $result ) {
		return array(
			'jsonrpc' => '2.0',
			'id'      => $id,
			'result'  => $result,
		);
	}

	private function error( $id, $code, $message ) {
		return array(
			'jsonrpc' => '2.0',
			'id'      => $id,
			'error'   => array(
				'code'    => $code,
				'message' => $message,
			),
		);
	}

	/**
	 * A failed tool call is reported as a successful JSON-RPC result whose
	 * content is flagged isError, per the MCP spec.
	 */
	private function tool_error( $id, $message ) {
		return $this->result(
			$id,
			array(
				'content' => array(
					array(
						'type' => 'text',
						'text' => $message,
					),
				),
				'isError' => true,
			)
		);
	}

	private function rest( $payload ) {
		if ( null === $payload ) {
			// Notification only: return 202 with empty body.
			return new WP_REST_Response( null, 202 );
		}
		$response = new WP_REST_Response( $payload, 200 );
		$response->header( 'Content-Type', 'application/json' );
		return $response;
	}
}
