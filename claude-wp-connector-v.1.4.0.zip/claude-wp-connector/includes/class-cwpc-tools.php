<?php
/**
 * Tool definitions and implementations for the Claude WP Connector.
 *
 * Every tool checks the acting user's capabilities before doing anything, so
 * the connection can never exceed the permissions of the WordPress user it
 * authenticated as.
 *
 * @package Claude_WP_Connector
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CWPC_Tools {

	/**
	 * Map of tool name => callable method on this class.
	 *
	 * @return array
	 */
	private function map() {
		return array(
			// Content.
			'cwpc_list_posts'            => 'list_posts',
			'cwpc_get_post'              => 'get_post',
			'cwpc_create_post'           => 'create_post',
			'cwpc_update_post'           => 'update_post',
			'cwpc_delete_post'           => 'delete_post',
			// Media.
			'cwpc_list_media'            => 'list_media',
			'cwpc_upload_media'          => 'upload_media',
			'cwpc_upload_media_base64'   => 'upload_media_base64',
			// Taxonomies.
			'cwpc_list_terms'            => 'list_terms',
			'cwpc_create_term'           => 'create_term',
			'cwpc_set_post_terms'        => 'set_post_terms',
			// Page builders.
			'cwpc_detect_builder'        => 'detect_builder',
			'cwpc_get_builder_content'   => 'get_builder_content',
			'cwpc_update_builder_content' => 'update_builder_content',
			// Site / diagnostics.
			'cwpc_site_info'             => 'site_info',
			'cwpc_get_debug_log'         => 'get_debug_log',
			// Administrator-level (gated by "Enable dangerous tools").
			'cwpc_list_users'            => 'list_users',
			'cwpc_get_option'            => 'get_option_tool',
			'cwpc_update_option'         => 'update_option_tool',
			'cwpc_list_plugins'          => 'list_plugins',
			'cwpc_manage_plugin'         => 'manage_plugin',
			// SEO, meta & media.
			'cwpc_set_seo'               => 'set_seo',
			'cwpc_set_media_meta'        => 'set_media_meta',
			'cwpc_set_featured_image'    => 'set_featured_image',
			'cwpc_set_comment_status'    => 'set_comment_status',
			'cwpc_get_post_meta'         => 'get_post_meta_tool',
			'cwpc_set_post_meta'         => 'set_post_meta_tool',
			// Plugins & themes (gated).
			'cwpc_install_plugin'        => 'install_plugin',
			'cwpc_update_plugin'         => 'update_plugin',
			'cwpc_delete_plugin'         => 'delete_plugin',
			'cwpc_list_themes'           => 'list_themes',
			'cwpc_install_theme'         => 'install_theme',
			'cwpc_activate_theme'        => 'activate_theme',
			'cwpc_delete_theme'          => 'delete_theme',
			// REST passthrough (gated) — reach ANY active plugin/theme REST route.
			'cwpc_rest_discover'         => 'rest_discover',
			'cwpc_rest_call'             => 'rest_call',
		);
	}

	/**
	 * Dispatch a tool call by name.
	 *
	 * @param string $name Tool name.
	 * @param array  $args Arguments.
	 * @return mixed|WP_Error
	 */
	public function call( $name, $args ) {
		$map = $this->map();
		if ( ! isset( $map[ $name ] ) ) {
			return new WP_Error( 'cwpc_unknown_tool', 'Unknown tool: ' . $name );
		}
		return call_user_func( array( $this, $map[ $name ] ), $args );
	}

	/* ================================================================== */
	/*  Tool schema definitions (returned by tools/list)                  */
	/* ================================================================== */

	public function definitions() {
		$post_type_prop = array(
			'type'        => 'string',
			'description' => 'Post type slug, e.g. "post", "page", or a custom type. Defaults to "post".',
		);

		$defs = array(
			array(
				'name'        => 'cwpc_list_posts',
				'description' => 'List or search posts/pages. Returns id, title, status, type, link, and modified date.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_type' => $post_type_prop,
						'status'    => array( 'type' => 'string', 'description' => 'any, publish, draft, pending, private, future, trash. Default any.' ),
						'search'    => array( 'type' => 'string', 'description' => 'Keyword to search titles/content.' ),
						'per_page'  => array( 'type' => 'integer', 'description' => 'Max results (1-100). Default 20.' ),
						'page'      => array( 'type' => 'integer', 'description' => 'Page number for pagination. Default 1.' ),
					),
				),
			),
			array(
				'name'        => 'cwpc_get_post',
				'description' => 'Get a single post/page in full, including raw content, excerpt, slug, meta, and builder detection.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'id' => array( 'type' => 'integer', 'description' => 'Post ID.' ),
					),
					'required'   => array( 'id' ),
				),
			),
			array(
				'name'        => 'cwpc_create_post',
				'description' => 'Create a new post or page. To schedule it, pass a future "date" (site timezone) or "date_gmt" (UTC) and it becomes a native WordPress scheduled ("future") post.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'title'     => array( 'type' => 'string' ),
						'content'   => array( 'type' => 'string', 'description' => 'Post body. HTML or Gutenberg block markup.' ),
						'status'    => array( 'type' => 'string', 'description' => 'draft, publish, pending, private, future. Default draft. If a future "date"/"date_gmt" is given without a status, the post is scheduled automatically.' ),
						'date'      => array( 'type' => 'string', 'description' => 'Publish date/time in the SITE timezone, e.g. "2026-07-06 07:30:00" or ISO 8601. A future value schedules the post.' ),
						'date_gmt'  => array( 'type' => 'string', 'description' => 'Publish date/time in UTC, e.g. "2026-07-05 23:30:00". Takes precedence over "date" if both are given.' ),
						'post_type' => $post_type_prop,
						'excerpt'   => array( 'type' => 'string' ),
						'slug'      => array( 'type' => 'string' ),
						'parent'    => array( 'type' => 'integer', 'description' => 'Parent post ID (for pages).' ),
					),
					'required'   => array( 'title' ),
				),
			),
			array(
				'name'        => 'cwpc_update_post',
				'description' => 'Update an existing post or page. Only the fields you pass are changed. To schedule a draft, pass a future "date" (site timezone) or "date_gmt" (UTC) and it becomes a native WordPress scheduled ("future") post.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'id'      => array( 'type' => 'integer' ),
						'title'   => array( 'type' => 'string' ),
						'content' => array( 'type' => 'string' ),
						'status'   => array( 'type' => 'string', 'description' => 'draft, publish, pending, private, future. If a future "date"/"date_gmt" is given without a status, the post is scheduled automatically.' ),
						'date'     => array( 'type' => 'string', 'description' => 'Publish date/time in the SITE timezone, e.g. "2026-07-06 07:30:00" or ISO 8601. A future value schedules the post.' ),
						'date_gmt' => array( 'type' => 'string', 'description' => 'Publish date/time in UTC, e.g. "2026-07-05 23:30:00". Takes precedence over "date" if both are given.' ),
						'excerpt' => array( 'type' => 'string' ),
						'slug'    => array( 'type' => 'string' ),
					),
					'required'   => array( 'id' ),
				),
			),
			array(
				'name'        => 'cwpc_delete_post',
				'description' => 'Move a post to trash, or permanently delete it.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'id'    => array( 'type' => 'integer' ),
						'force' => array( 'type' => 'boolean', 'description' => 'true = delete permanently, false = trash. Default false.' ),
					),
					'required'   => array( 'id' ),
				),
			),
			array(
				'name'        => 'cwpc_list_media',
				'description' => 'List media library items (images, files).',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'search'   => array( 'type' => 'string' ),
						'per_page' => array( 'type' => 'integer', 'description' => 'Default 20.' ),
					),
				),
			),
			array(
				'name'        => 'cwpc_upload_media',
				'description' => 'Upload a file to the media library from a public URL. Returns the attachment id and URL.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'url'         => array( 'type' => 'string', 'description' => 'Public URL of the file to download and import.' ),
						'title'       => array( 'type' => 'string' ),
						'alt'         => array( 'type' => 'string', 'description' => 'Alt text for images.' ),
						'attach_to'   => array( 'type' => 'integer', 'description' => 'Optional post ID to attach the media to.' ),
						'set_featured' => array( 'type' => 'boolean', 'description' => 'If attach_to is set, also make this the featured image.' ),
					),
					'required'   => array( 'url' ),
				),
			),
			array(
				'name'        => 'cwpc_upload_media_base64',
				'description' => 'Upload a file to the media library directly from base64-encoded bytes (no public URL needed). Ideal for images generated on the fly. Optionally attach it to a post, set it as the featured image, and apply alt/caption/description. Returns the attachment id and URL.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'data'         => array( 'type' => 'string', 'description' => 'Base64-encoded file contents. A "data:...;base64," prefix is accepted and stripped automatically.' ),
						'filename'     => array( 'type' => 'string', 'description' => 'Filename WITH extension, e.g. "featured.png". The extension sets the MIME type and must be an allowed WordPress upload type.' ),
						'title'        => array( 'type' => 'string' ),
						'alt'          => array( 'type' => 'string', 'description' => 'Alt text for images.' ),
						'caption'      => array( 'type' => 'string' ),
						'description'  => array( 'type' => 'string' ),
						'attach_to'    => array( 'type' => 'integer', 'description' => 'Optional post ID to attach the media to.' ),
						'set_featured' => array( 'type' => 'boolean', 'description' => 'If attach_to is set, also make this the featured image.' ),
					),
					'required'   => array( 'data', 'filename' ),
				),
			),
			array(
				'name'        => 'cwpc_list_terms',
				'description' => 'List terms in a taxonomy (e.g. categories or tags).',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'taxonomy' => array( 'type' => 'string', 'description' => 'category, post_tag, or any registered taxonomy. Default category.' ),
						'search'   => array( 'type' => 'string' ),
					),
				),
			),
			array(
				'name'        => 'cwpc_create_term',
				'description' => 'Create a taxonomy term (category, tag, etc.).',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'taxonomy'    => array( 'type' => 'string', 'description' => 'Default category.' ),
						'name'        => array( 'type' => 'string' ),
						'description' => array( 'type' => 'string' ),
						'parent'      => array( 'type' => 'integer' ),
					),
					'required'   => array( 'name' ),
				),
			),
			array(
				'name'        => 'cwpc_set_post_terms',
				'description' => 'Assign terms to a post. Replaces existing terms in that taxonomy unless append is true.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id'  => array( 'type' => 'integer' ),
						'taxonomy' => array( 'type' => 'string', 'description' => 'Default category.' ),
						'terms'    => array( 'type' => 'array', 'items' => array( 'type' => 'string' ), 'description' => 'Term names or IDs.' ),
						'append'   => array( 'type' => 'boolean' ),
					),
					'required'   => array( 'post_id', 'terms' ),
				),
			),
			array(
				'name'        => 'cwpc_detect_builder',
				'description' => 'Detect which page builder a post uses: gutenberg, elementor, divi, beaver, or classic.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array( 'id' => array( 'type' => 'integer' ) ),
					'required'   => array( 'id' ),
				),
			),
			array(
				'name'        => 'cwpc_get_builder_content',
				'description' => 'Get the editable builder payload for a post: Elementor JSON, Divi shortcode content, Beaver Builder data, or Gutenberg/classic HTML.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array( 'id' => array( 'type' => 'integer' ) ),
					'required'   => array( 'id' ),
				),
			),
			array(
				'name'        => 'cwpc_update_builder_content',
				'description' => 'Update a post\'s builder content. For elementor pass a JSON string in "data"; for divi/gutenberg/classic pass HTML/shortcode in "content"; for beaver pass a JSON string in "data".',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'id'      => array( 'type' => 'integer' ),
						'builder' => array( 'type' => 'string', 'description' => 'elementor, divi, beaver, gutenberg, or classic. If omitted, auto-detected.' ),
						'content' => array( 'type' => 'string', 'description' => 'HTML/shortcode body (divi, gutenberg, classic).' ),
						'data'    => array( 'type' => 'string', 'description' => 'JSON string of builder data (elementor, beaver).' ),
					),
					'required'   => array( 'id' ),
				),
			),
			array(
				'name'        => 'cwpc_site_info',
				'description' => 'Get site details: name, URL, WordPress version, active theme, active plugins, registered post types and taxonomies.',
				'inputSchema' => array( 'type' => 'object', 'properties' => new stdClass() ),
			),
			array(
				'name'        => 'cwpc_get_debug_log',
				'description' => 'Read the tail of the WordPress debug.log to find PHP errors and warnings. Requires WP_DEBUG_LOG enabled.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'lines' => array( 'type' => 'integer', 'description' => 'Number of trailing lines to return (max 500). Default 100.' ),
					),
				),
			),
			array(
				'name'        => 'cwpc_list_users',
				'description' => '[Admin] List WordPress users with their roles. Requires "Enable dangerous tools".',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'search'   => array( 'type' => 'string' ),
						'role'     => array( 'type' => 'string' ),
						'per_page' => array( 'type' => 'integer' ),
					),
				),
			),
			array(
				'name'        => 'cwpc_get_option',
				'description' => '[Admin] Read a WordPress option value. Requires "Enable dangerous tools".',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array( 'name' => array( 'type' => 'string' ) ),
					'required'   => array( 'name' ),
				),
			),
			array(
				'name'        => 'cwpc_update_option',
				'description' => '[Admin] Update a WordPress option (e.g. blogname, blogdescription). Requires "Enable dangerous tools".',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'name'  => array( 'type' => 'string' ),
						'value' => array( 'type' => 'string' ),
					),
					'required'   => array( 'name', 'value' ),
				),
			),
			array(
				'name'        => 'cwpc_list_plugins',
				'description' => '[Admin] List installed plugins and whether each is active. Requires "Enable dangerous tools".',
				'inputSchema' => array( 'type' => 'object', 'properties' => new stdClass() ),
			),
			array(
				'name'        => 'cwpc_manage_plugin',
				'description' => '[Admin] Activate or deactivate a plugin by its folder/file path (e.g. "elementor/elementor.php"). Requires "Enable dangerous tools".',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'plugin' => array( 'type' => 'string' ),
						'action' => array( 'type' => 'string', 'description' => 'activate or deactivate.' ),
					),
					'required'   => array( 'plugin', 'action' ),
				),
			),
			array(
				'name'        => 'cwpc_set_seo',
				'description' => 'Set SEO fields on a post for Yoast and Rank Math: focus keyphrase, SEO title, meta description, and canonical URL. Only the fields you pass are changed.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id'          => array( 'type' => 'integer' ),
						'focus_keyphrase'  => array( 'type' => 'string' ),
						'seo_title'        => array( 'type' => 'string' ),
						'meta_description' => array( 'type' => 'string' ),
						'canonical'        => array( 'type' => 'string' ),
					),
					'required'   => array( 'post_id' ),
				),
			),
			array(
				'name'        => 'cwpc_set_media_meta',
				'description' => 'Set an image/attachment SEO metadata: alt text, title, caption, and description.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'id'          => array( 'type' => 'integer', 'description' => 'Attachment ID.' ),
						'alt'         => array( 'type' => 'string' ),
						'title'       => array( 'type' => 'string' ),
						'caption'     => array( 'type' => 'string' ),
						'description' => array( 'type' => 'string' ),
					),
					'required'   => array( 'id' ),
				),
			),
			array(
				'name'        => 'cwpc_set_featured_image',
				'description' => 'Set a post featured image to an existing media attachment ID.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id'       => array( 'type' => 'integer' ),
						'attachment_id' => array( 'type' => 'integer' ),
					),
					'required'   => array( 'post_id', 'attachment_id' ),
				),
			),
			array(
				'name'        => 'cwpc_set_comment_status',
				'description' => 'Open or close comments (and optionally pingbacks) on a post or page.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id'     => array( 'type' => 'integer' ),
						'status'      => array( 'type' => 'string', 'description' => 'open or closed.' ),
						'ping_status' => array( 'type' => 'string', 'description' => 'open or closed (optional).' ),
					),
					'required'   => array( 'post_id', 'status' ),
				),
			),
			array(
				'name'        => 'cwpc_get_post_meta',
				'description' => 'Read post meta. Pass a key for a single value, or omit it to return all safe meta.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id' => array( 'type' => 'integer' ),
						'key'     => array( 'type' => 'string' ),
					),
					'required'   => array( 'post_id' ),
				),
			),
			array(
				'name'        => 'cwpc_set_post_meta',
				'description' => '[Admin] Set any post meta key to a value. Requires "Enable dangerous tools".',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id' => array( 'type' => 'integer' ),
						'key'     => array( 'type' => 'string' ),
						'value'   => array( 'type' => 'string' ),
					),
					'required'   => array( 'post_id', 'key', 'value' ),
				),
			),
			array(
				'name'        => 'cwpc_install_plugin',
				'description' => '[Admin] Install a plugin from the WordPress.org repository by slug (e.g. "wordpress-seo"), optionally activating it. Requires "Enable dangerous tools".',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'slug'     => array( 'type' => 'string', 'description' => 'WordPress.org plugin slug.' ),
						'activate' => array( 'type' => 'boolean', 'description' => 'Activate after install. Default false.' ),
					),
					'required'   => array( 'slug' ),
				),
			),
			array(
				'name'        => 'cwpc_update_plugin',
				'description' => '[Admin] Update an installed plugin to the latest version. Requires "Enable dangerous tools".',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'plugin' => array( 'type' => 'string', 'description' => 'Plugin file path, e.g. "wordpress-seo/wp-seo.php".' ),
					),
					'required'   => array( 'plugin' ),
				),
			),
			array(
				'name'        => 'cwpc_delete_plugin',
				'description' => '[Admin] Deactivate if needed and delete a plugin by its file path. Requires "Enable dangerous tools".',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'plugin' => array( 'type' => 'string' ),
					),
					'required'   => array( 'plugin' ),
				),
			),
			array(
				'name'        => 'cwpc_list_themes',
				'description' => '[Admin] List installed themes with version and which is active. Requires "Enable dangerous tools".',
				'inputSchema' => array( 'type' => 'object', 'properties' => new stdClass() ),
			),
			array(
				'name'        => 'cwpc_install_theme',
				'description' => '[Admin] Install a theme from the WordPress.org repository by slug (e.g. "astra"), optionally activating it. Requires "Enable dangerous tools".',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'slug'     => array( 'type' => 'string' ),
						'activate' => array( 'type' => 'boolean' ),
					),
					'required'   => array( 'slug' ),
				),
			),
			array(
				'name'        => 'cwpc_activate_theme',
				'description' => '[Admin] Activate an installed theme by its stylesheet (folder name). Requires "Enable dangerous tools".',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'stylesheet' => array( 'type' => 'string' ),
					),
					'required'   => array( 'stylesheet' ),
				),
			),
			array(
				'name'        => 'cwpc_delete_theme',
				'description' => '[Admin] Delete an installed theme by its stylesheet. Cannot delete the active theme. Requires "Enable dangerous tools".',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'stylesheet' => array( 'type' => 'string' ),
					),
					'required'   => array( 'stylesheet' ),
				),
			),
			array(
				'name'        => 'cwpc_rest_discover',
				'description' => '[Admin] Discover EVERY REST route registered on this site by core AND all active plugins/themes (e.g. Code Snippets, WooCommerce, Yoast), with the HTTP methods each supports. Use this to find a plugin\'s endpoints before calling them with cwpc_rest_call. Requires "Enable dangerous tools".',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'namespace' => array( 'type' => 'string', 'description' => 'Optional. Only routes in this namespace, e.g. "wp/v2" or "code-snippets/v1".' ),
						'search'    => array( 'type' => 'string', 'description' => 'Optional. Only routes whose path contains this substring, e.g. "snippet".' ),
					),
				),
			),
			array(
				'name'        => 'cwpc_rest_call',
				'description' => '[Admin] Broad passthrough: invoke ANY registered REST route on this site and return its status + JSON. This reaches plugin features that expose a REST API (Code Snippets Pro, WooCommerce, etc.). Dispatched internally, so the target route STILL enforces its own permission checks. Requires "Enable dangerous tools".',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'method' => array( 'type' => 'string', 'description' => 'GET, POST, PUT, PATCH, or DELETE. Default GET.' ),
						'route'  => array( 'type' => 'string', 'description' => 'Target route path, e.g. "/wp/v2/posts" or "/code-snippets/v1/snippets".' ),
						'query'  => array( 'type' => 'object', 'description' => 'Optional query-string parameters as an object.' ),
						'body'   => array( 'type' => 'object', 'description' => 'Optional body parameters as an object (for POST/PUT/PATCH/DELETE).' ),
					),
					'required'   => array( 'route' ),
				),
			),
		);

		return $defs;
	}

	/* ================================================================== */
	/*  Content tools                                                     */
	/* ================================================================== */

	public function list_posts( $args ) {
		$post_type = isset( $args['post_type'] ) ? sanitize_key( $args['post_type'] ) : 'post';
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to list posts.' );
		}

		$q = new WP_Query(
			array(
				'post_type'      => $post_type,
				'post_status'    => isset( $args['status'] ) ? sanitize_key( $args['status'] ) : 'any',
				's'              => isset( $args['search'] ) ? sanitize_text_field( $args['search'] ) : '',
				'posts_per_page' => isset( $args['per_page'] ) ? min( 100, max( 1, (int) $args['per_page'] ) ) : 20,
				'paged'          => isset( $args['page'] ) ? max( 1, (int) $args['page'] ) : 1,
			)
		);

		$items = array();
		foreach ( $q->posts as $p ) {
			$items[] = array(
				'id'       => $p->ID,
				'title'    => get_the_title( $p ),
				'status'   => $p->post_status,
				'type'     => $p->post_type,
				'slug'     => $p->post_name,
				'link'     => get_permalink( $p ),
				'modified' => $p->post_modified,
			);
		}

		return array(
			'total'      => (int) $q->found_posts,
			'totalPages' => (int) $q->max_num_pages,
			'items'      => $items,
		);
	}

	public function get_post( $args ) {
		$id = isset( $args['id'] ) ? (int) $args['id'] : 0;
		$p  = get_post( $id );
		if ( ! $p ) {
			return new WP_Error( 'cwpc_not_found', 'Post not found.' );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to view this post.' );
		}

		return array(
			'id'       => $p->ID,
			'title'    => $p->post_title,
			'status'   => $p->post_status,
			'type'     => $p->post_type,
			'slug'     => $p->post_name,
			'link'     => get_permalink( $p ),
			'excerpt'  => $p->post_excerpt,
			'content'  => $p->post_content,
			'parent'   => $p->post_parent,
			'author'   => (int) $p->post_author,
			'modified' => $p->post_modified,
			'builder'  => $this->which_builder( $p ),
			'meta'     => $this->safe_meta( $id ),
		);
	}

	/**
	 * Build post_date / post_date_gmt from a "date" (site local) or "date_gmt" (UTC) argument.
	 * Accepts "Y-m-d H:i:s", ISO 8601, or anything DateTime understands. Returns null if none/invalid.
	 *
	 * @param array $args Tool arguments.
	 * @return array|null array( post_date, post_date_gmt, ts ) or null.
	 */
	private function build_schedule_dates( $args ) {
		$raw    = '';
		$is_gmt = false;
		if ( isset( $args['date_gmt'] ) && '' !== trim( (string) $args['date_gmt'] ) ) {
			$raw    = trim( (string) $args['date_gmt'] );
			$is_gmt = true;
		} elseif ( isset( $args['date'] ) && '' !== trim( (string) $args['date'] ) ) {
			$raw = trim( (string) $args['date'] );
		}
		if ( '' === $raw ) {
			return null;
		}
		$base_tz = $is_gmt ? new DateTimeZone( 'UTC' ) : wp_timezone();
		try {
			$dt = new DateTime( $raw, $base_tz );
		} catch ( Exception $e ) {
			return null;
		}
		$utc = clone $dt;
		$utc->setTimezone( new DateTimeZone( 'UTC' ) );
		$local = clone $dt;
		$local->setTimezone( wp_timezone() );
		return array(
			'post_date'     => $local->format( 'Y-m-d H:i:s' ),
			'post_date_gmt' => $utc->format( 'Y-m-d H:i:s' ),
			'ts'            => (int) $utc->format( 'U' ),
		);
	}

	public function create_post( $args ) {
		$post_type = isset( $args['post_type'] ) ? sanitize_key( $args['post_type'] ) : 'post';
		$cap       = ( 'page' === $post_type ) ? 'publish_pages' : 'publish_posts';
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to create content.' );
		}

		$postarr = array(
			'post_type'    => $post_type,
			'post_title'   => isset( $args['title'] ) ? sanitize_text_field( $args['title'] ) : '',
			'post_content' => isset( $args['content'] ) ? (string) $args['content'] : '',
			'post_status'  => isset( $args['status'] ) ? sanitize_key( $args['status'] ) : 'draft',
			'post_excerpt' => isset( $args['excerpt'] ) ? sanitize_text_field( $args['excerpt'] ) : '',
		);
		if ( isset( $args['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( $args['slug'] );
		}
		if ( isset( $args['parent'] ) ) {
			$postarr['post_parent'] = (int) $args['parent'];
		}

		// --- Scheduling support (v1.3.0): a future date/date_gmt schedules the post. ---
		$schedule = $this->build_schedule_dates( $args );
		if ( $schedule ) {
			$postarr['post_date']     = $schedule['post_date'];
			$postarr['post_date_gmt'] = $schedule['post_date_gmt'];
			$postarr['edit_date']     = true;
			$cwpc_req_status          = isset( $args['status'] ) ? sanitize_key( $args['status'] ) : '';
			if ( $schedule['ts'] > time() && ( '' === $cwpc_req_status || 'future' === $cwpc_req_status || 'publish' === $cwpc_req_status ) ) {
				$postarr['post_status'] = 'future';
			}
		}

		$id = wp_insert_post( $postarr, true );
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		return array(
			'id'     => $id,
			'link'   => get_permalink( $id ),
			'status' => get_post_status( $id ),
			'edit'   => get_edit_post_link( $id, 'raw' ),
		);
	}

	public function update_post( $args ) {
		$id = isset( $args['id'] ) ? (int) $args['id'] : 0;
		if ( ! get_post( $id ) ) {
			return new WP_Error( 'cwpc_not_found', 'Post not found.' );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to edit this post.' );
		}

		$postarr = array( 'ID' => $id );
		if ( isset( $args['title'] ) ) {
			$postarr['post_title'] = sanitize_text_field( $args['title'] );
		}
		if ( isset( $args['content'] ) ) {
			$postarr['post_content'] = (string) $args['content'];
		}
		if ( isset( $args['status'] ) ) {
			$postarr['post_status'] = sanitize_key( $args['status'] );
		}
		if ( isset( $args['excerpt'] ) ) {
			$postarr['post_excerpt'] = sanitize_text_field( $args['excerpt'] );
		}
		if ( isset( $args['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( $args['slug'] );
		}

		// --- Scheduling support (v1.3.0): a future date/date_gmt schedules the post. ---
		$schedule = $this->build_schedule_dates( $args );
		if ( $schedule ) {
			$postarr['post_date']     = $schedule['post_date'];
			$postarr['post_date_gmt'] = $schedule['post_date_gmt'];
			$postarr['edit_date']     = true;
			$cwpc_req_status          = isset( $args['status'] ) ? sanitize_key( $args['status'] ) : '';
			if ( $schedule['ts'] > time() && ( '' === $cwpc_req_status || 'future' === $cwpc_req_status || 'publish' === $cwpc_req_status ) ) {
				$postarr['post_status'] = 'future';
			}
		}

		$result = wp_update_post( $postarr, true );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array(
			'id'      => $id,
			'updated' => true,
			'link'    => get_permalink( $id ),
			'status'  => get_post_status( $id ),
		);
	}

	public function delete_post( $args ) {
		$id    = isset( $args['id'] ) ? (int) $args['id'] : 0;
		$force = ! empty( $args['force'] );
		if ( ! get_post( $id ) ) {
			return new WP_Error( 'cwpc_not_found', 'Post not found.' );
		}
		if ( ! current_user_can( 'delete_post', $id ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to delete this post.' );
		}
		$res = wp_delete_post( $id, $force );
		if ( ! $res ) {
			return new WP_Error( 'cwpc_delete_failed', 'Delete failed.' );
		}
		return array(
			'id'      => $id,
			'deleted' => true,
			'forced'  => $force,
		);
	}

	/* ================================================================== */
	/*  Media tools                                                       */
	/* ================================================================== */

	public function list_media( $args ) {
		if ( ! current_user_can( 'upload_files' ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to view media.' );
		}
		$q = new WP_Query(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				's'              => isset( $args['search'] ) ? sanitize_text_field( $args['search'] ) : '',
				'posts_per_page' => isset( $args['per_page'] ) ? min( 100, max( 1, (int) $args['per_page'] ) ) : 20,
			)
		);
		$items = array();
		foreach ( $q->posts as $p ) {
			$items[] = array(
				'id'        => $p->ID,
				'title'     => $p->post_title,
				'mime'      => $p->post_mime_type,
				'url'       => wp_get_attachment_url( $p->ID ),
			);
		}
		return array( 'total' => (int) $q->found_posts, 'items' => $items );
	}

	public function upload_media( $args ) {
		if ( ! current_user_can( 'upload_files' ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to upload files.' );
		}
		$url = isset( $args['url'] ) ? esc_url_raw( $args['url'] ) : '';
		if ( ! $url ) {
			return new WP_Error( 'cwpc_bad_arg', 'A valid url is required.' );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$tmp = download_url( $url );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}

		$file_array = array(
			'name'     => basename( wp_parse_url( $url, PHP_URL_PATH ) ),
			'tmp_name' => $tmp,
		);

		$attach_to = isset( $args['attach_to'] ) ? (int) $args['attach_to'] : 0;
		$id        = media_handle_sideload( $file_array, $attach_to, isset( $args['title'] ) ? sanitize_text_field( $args['title'] ) : null );

		if ( is_wp_error( $id ) ) {
			@unlink( $tmp );
			return $id;
		}

		if ( isset( $args['alt'] ) ) {
			update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( $args['alt'] ) );
		}
		if ( $attach_to && ! empty( $args['set_featured'] ) ) {
			set_post_thumbnail( $attach_to, $id );
		}

		return array(
			'id'  => $id,
			'url' => wp_get_attachment_url( $id ),
		);
	}

	public function upload_media_base64( $args ) {
		if ( ! current_user_can( 'upload_files' ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to upload files.' );
		}

		$data = isset( $args['data'] ) ? (string) $args['data'] : '';
		if ( '' === $data ) {
			return new WP_Error( 'cwpc_bad_arg', 'Base64 file "data" is required.' );
		}

		// Strip a data: URI prefix if present (e.g. "data:image/png;base64,....").
		if ( 0 === strpos( $data, 'data:' ) ) {
			$comma = strpos( $data, ',' );
			if ( false !== $comma ) {
				$data = substr( $data, $comma + 1 );
			}
		}
		// Remove any whitespace/newlines that can appear in a base64 payload.
		$data = preg_replace( '/\\s+/', '', $data );

		$decoded = base64_decode( $data, true );
		if ( false === $decoded || '' === $decoded ) {
			return new WP_Error( 'cwpc_bad_arg', 'The "data" value is not valid base64.' );
		}

		$filename = isset( $args['filename'] ) ? sanitize_file_name( $args['filename'] ) : '';
		if ( '' === $filename ) {
			return new WP_Error( 'cwpc_bad_arg', 'A "filename" (with extension) is required.' );
		}

		// Validate the extension against WordPress' allowed upload types.
		$filetype = wp_check_filetype( $filename );
		if ( empty( $filetype['ext'] ) || empty( $filetype['type'] ) ) {
			return new WP_Error( 'cwpc_bad_type', 'The file extension is not an allowed upload type.' );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		// Write the decoded bytes into the uploads directory.
		$upload = wp_upload_bits( $filename, null, $decoded );
		if ( ! empty( $upload['error'] ) ) {
			return new WP_Error( 'cwpc_upload_failed', $upload['error'] );
		}

		$attach_to = isset( $args['attach_to'] ) ? (int) $args['attach_to'] : 0;

		$attachment = array(
			'post_mime_type' => $filetype['type'],
			'post_title'     => isset( $args['title'] ) ? sanitize_text_field( $args['title'] ) : preg_replace( '/\\.[^.]+$/', '', $filename ),
			'post_content'   => isset( $args['description'] ) ? wp_kses_post( $args['description'] ) : '',
			'post_excerpt'   => isset( $args['caption'] ) ? sanitize_text_field( $args['caption'] ) : '',
			'post_status'    => 'inherit',
		);

		$id = wp_insert_attachment( $attachment, $upload['file'], $attach_to, true );
		if ( is_wp_error( $id ) ) {
			@unlink( $upload['file'] );
			return $id;
		}

		// Generate thumbnail sizes and attachment metadata.
		$metadata = wp_generate_attachment_metadata( $id, $upload['file'] );
		wp_update_attachment_metadata( $id, $metadata );

		if ( isset( $args['alt'] ) ) {
			update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( $args['alt'] ) );
		}
		if ( $attach_to && ! empty( $args['set_featured'] ) ) {
			set_post_thumbnail( $attach_to, $id );
		}

		return array(
			'id'  => $id,
			'url' => wp_get_attachment_url( $id ),
		);
	}

	/* ================================================================== */
	/*  Taxonomy tools                                                    */
	/* ================================================================== */

	public function list_terms( $args ) {
		$tax = isset( $args['taxonomy'] ) ? sanitize_key( $args['taxonomy'] ) : 'category';
		if ( ! taxonomy_exists( $tax ) ) {
			return new WP_Error( 'cwpc_bad_tax', 'Taxonomy does not exist: ' . $tax );
		}
		$terms = get_terms(
			array(
				'taxonomy'   => $tax,
				'hide_empty' => false,
				'search'     => isset( $args['search'] ) ? sanitize_text_field( $args['search'] ) : '',
			)
		);
		if ( is_wp_error( $terms ) ) {
			return $terms;
		}
		$out = array();
		foreach ( $terms as $t ) {
			$out[] = array(
				'id'     => $t->term_id,
				'name'   => $t->name,
				'slug'   => $t->slug,
				'count'  => $t->count,
				'parent' => $t->parent,
			);
		}
		return $out;
	}

	public function create_term( $args ) {
		$tax = isset( $args['taxonomy'] ) ? sanitize_key( $args['taxonomy'] ) : 'category';
		if ( ! taxonomy_exists( $tax ) ) {
			return new WP_Error( 'cwpc_bad_tax', 'Taxonomy does not exist: ' . $tax );
		}
		$tax_obj = get_taxonomy( $tax );
		if ( ! current_user_can( $tax_obj->cap->manage_terms ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to manage this taxonomy.' );
		}
		$res = wp_insert_term(
			sanitize_text_field( $args['name'] ),
			$tax,
			array(
				'description' => isset( $args['description'] ) ? sanitize_text_field( $args['description'] ) : '',
				'parent'      => isset( $args['parent'] ) ? (int) $args['parent'] : 0,
			)
		);
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		return array( 'id' => $res['term_id'], 'taxonomy' => $tax );
	}

	public function set_post_terms( $args ) {
		$post_id = isset( $args['post_id'] ) ? (int) $args['post_id'] : 0;
		$tax     = isset( $args['taxonomy'] ) ? sanitize_key( $args['taxonomy'] ) : 'category';
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to edit this post.' );
		}
		$terms  = isset( $args['terms'] ) && is_array( $args['terms'] ) ? $args['terms'] : array();
		$append = ! empty( $args['append'] );

		// Convert numeric strings to integers so IDs are matched, names stay as names.
		$prepared = array();
		foreach ( $terms as $term ) {
			$prepared[] = is_numeric( $term ) ? (int) $term : sanitize_text_field( $term );
		}

		$res = wp_set_object_terms( $post_id, $prepared, $tax, $append );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		return array( 'post_id' => $post_id, 'taxonomy' => $tax, 'assigned' => $res );
	}

	/* ================================================================== */
	/*  Page builder tools                                                */
	/* ================================================================== */

	private function which_builder( $post ) {
		$id = $post->ID;
		if ( 'builder' === get_post_meta( $id, '_elementor_edit_mode', true ) ) {
			return 'elementor';
		}
		if ( 'on' === get_post_meta( $id, '_et_pb_use_builder', true ) || false !== strpos( (string) $post->post_content, '[et_pb_section' ) ) {
			return 'divi';
		}
		if ( get_post_meta( $id, '_fl_builder_enabled', true ) ) {
			return 'beaver';
		}
		if ( false !== strpos( (string) $post->post_content, '<!-- wp:' ) ) {
			return 'gutenberg';
		}
		return 'classic';
	}

	public function detect_builder( $args ) {
		$id = isset( $args['id'] ) ? (int) $args['id'] : 0;
		$p  = get_post( $id );
		if ( ! $p ) {
			return new WP_Error( 'cwpc_not_found', 'Post not found.' );
		}
		return array( 'id' => $id, 'builder' => $this->which_builder( $p ) );
	}

	public function get_builder_content( $args ) {
		$id = isset( $args['id'] ) ? (int) $args['id'] : 0;
		$p  = get_post( $id );
		if ( ! $p ) {
			return new WP_Error( 'cwpc_not_found', 'Post not found.' );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to edit this post.' );
		}
		$builder = $this->which_builder( $p );
		$out     = array( 'id' => $id, 'builder' => $builder );

		switch ( $builder ) {
			case 'elementor':
				$out['data']  = get_post_meta( $id, '_elementor_data', true ); // JSON string.
				$out['notes'] = 'Elementor data is a JSON string of the widget tree. Edit and send back via cwpc_update_builder_content with builder=elementor and the JSON in "data".';
				break;
			case 'beaver':
				$raw          = get_post_meta( $id, '_fl_builder_data', true );
				$out['data']  = wp_json_encode( $raw );
				$out['notes'] = 'Beaver Builder data is a structured object. Edit carefully and send back as a JSON string in "data".';
				break;
			case 'divi':
			case 'gutenberg':
			case 'classic':
			default:
				$out['content'] = $p->post_content;
				$out['notes']   = 'This is the post_content. Edit the HTML/shortcode/block markup and send back via cwpc_update_builder_content with "content".';
				break;
		}
		return $out;
	}

	public function update_builder_content( $args ) {
		$id = isset( $args['id'] ) ? (int) $args['id'] : 0;
		$p  = get_post( $id );
		if ( ! $p ) {
			return new WP_Error( 'cwpc_not_found', 'Post not found.' );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to edit this post.' );
		}
		$builder = isset( $args['builder'] ) ? sanitize_key( $args['builder'] ) : $this->which_builder( $p );

		switch ( $builder ) {
			case 'elementor':
				if ( ! isset( $args['data'] ) ) {
					return new WP_Error( 'cwpc_bad_arg', 'Elementor updates require a JSON string in "data".' );
				}
				$decoded = json_decode( (string) $args['data'], true );
				if ( null === $decoded && JSON_ERROR_NONE !== json_last_error() ) {
					return new WP_Error( 'cwpc_bad_json', 'The "data" value is not valid JSON.' );
				}
				// Elementor stores slash-escaped JSON.
				update_post_meta( $id, '_elementor_data', wp_slash( wp_json_encode( $decoded ) ) );
				update_post_meta( $id, '_elementor_edit_mode', 'builder' );
				delete_post_meta( $id, '_elementor_css' ); // Force CSS regeneration.
				return array( 'id' => $id, 'builder' => 'elementor', 'updated' => true, 'note' => 'Clear Elementor cache if styles look stale.' );

			case 'beaver':
				if ( ! isset( $args['data'] ) ) {
					return new WP_Error( 'cwpc_bad_arg', 'Beaver updates require a JSON string in "data".' );
				}
				$decoded = json_decode( (string) $args['data'], true );
				if ( null === $decoded && JSON_ERROR_NONE !== json_last_error() ) {
					return new WP_Error( 'cwpc_bad_json', 'The "data" value is not valid JSON.' );
				}
				update_post_meta( $id, '_fl_builder_data', $decoded );
				update_post_meta( $id, '_fl_builder_enabled', 1 );
				return array( 'id' => $id, 'builder' => 'beaver', 'updated' => true );

			case 'divi':
			case 'gutenberg':
			case 'classic':
			default:
				if ( ! isset( $args['content'] ) ) {
					return new WP_Error( 'cwpc_bad_arg', 'This builder updates via "content".' );
				}
				$res = wp_update_post( array( 'ID' => $id, 'post_content' => (string) $args['content'] ), true );
				if ( is_wp_error( $res ) ) {
					return $res;
				}
				if ( 'divi' === $builder ) {
					update_post_meta( $id, '_et_pb_use_builder', 'on' );
				}
				return array( 'id' => $id, 'builder' => $builder, 'updated' => true );
		}
	}

	/* ================================================================== */
	/*  Site / diagnostics                                                */
	/* ================================================================== */

	public function site_info( $args ) {
		$theme = wp_get_theme();
		return array(
			'name'        => get_bloginfo( 'name' ),
			'description' => get_bloginfo( 'description' ),
			'url'         => home_url(),
			'wp_version'  => get_bloginfo( 'version' ),
			'php_version' => PHP_VERSION,
			'theme'       => array( 'name' => $theme->get( 'Name' ), 'version' => $theme->get( 'Version' ) ),
			'post_types'  => array_values( get_post_types( array( 'public' => true ), 'names' ) ),
			'taxonomies'  => array_values( get_taxonomies( array(), 'names' ) ),
			'is_ssl'      => is_ssl(),
		);
	}

	public function get_debug_log( $args ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'cwpc_cap', 'Only administrators can read the debug log.' );
		}
		$lines = isset( $args['lines'] ) ? min( 500, max( 1, (int) $args['lines'] ) ) : 100;
		$path  = defined( 'WP_DEBUG_LOG' ) && is_string( WP_DEBUG_LOG ) ? WP_DEBUG_LOG : WP_CONTENT_DIR . '/debug.log';

		if ( ! file_exists( $path ) ) {
			return array( 'available' => false, 'note' => 'No debug.log found. Enable WP_DEBUG and WP_DEBUG_LOG in wp-config.php.' );
		}
		$content = file( $path, FILE_IGNORE_NEW_LINES );
		if ( false === $content ) {
			return new WP_Error( 'cwpc_read_failed', 'Could not read debug.log.' );
		}
		$tail = array_slice( $content, -$lines );
		return array( 'available' => true, 'path' => $path, 'lines' => count( $tail ), 'log' => implode( "\n", $tail ) );
	}

	/* ================================================================== */
	/*  Administrator-level tools (gated)                                 */
	/* ================================================================== */

	private function require_dangerous() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'cwpc_cap', 'Administrator capability required.' );
		}
		if ( ! (int) get_option( 'cwpc_allow_dangerous', 0 ) ) {
			return new WP_Error( 'cwpc_disabled', 'This tool is disabled. Turn on "Enable dangerous tools" in the plugin settings.' );
		}
		return true;
	}

	public function list_users( $args ) {
		$gate = $this->require_dangerous();
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}
		$users = get_users(
			array(
				'search'  => isset( $args['search'] ) ? '*' . sanitize_text_field( $args['search'] ) . '*' : '',
				'role'    => isset( $args['role'] ) ? sanitize_key( $args['role'] ) : '',
				'number'  => isset( $args['per_page'] ) ? min( 100, max( 1, (int) $args['per_page'] ) ) : 50,
			)
		);
		$out = array();
		foreach ( $users as $u ) {
			$out[] = array(
				'id'    => $u->ID,
				'login' => $u->user_login,
				'email' => $u->user_email,
				'roles' => $u->roles,
			);
		}
		return $out;
	}

	public function get_option_tool( $args ) {
		$gate = $this->require_dangerous();
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}
		$name = sanitize_text_field( $args['name'] );
		return array( 'name' => $name, 'value' => get_option( $name ) );
	}

	public function update_option_tool( $args ) {
		$gate = $this->require_dangerous();
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}
		$name = sanitize_text_field( $args['name'] );
		$ok   = update_option( $name, $args['value'] );
		return array( 'name' => $name, 'updated' => (bool) $ok );
	}

	public function list_plugins( $args ) {
		$gate = $this->require_dangerous();
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$all = get_plugins();
		$out = array();
		foreach ( $all as $file => $data ) {
			$out[] = array(
				'plugin'  => $file,
				'name'    => $data['Name'],
				'version' => $data['Version'],
				'active'  => is_plugin_active( $file ),
			);
		}
		return $out;
	}

	public function manage_plugin( $args ) {
		$gate = $this->require_dangerous();
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}
		if ( ! function_exists( 'activate_plugin' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$plugin = sanitize_text_field( $args['plugin'] );
		$action = isset( $args['action'] ) ? sanitize_key( $args['action'] ) : '';

		if ( 'activate' === $action ) {
			$res = activate_plugin( $plugin );
			if ( is_wp_error( $res ) ) {
				return $res;
			}
			return array( 'plugin' => $plugin, 'active' => true );
		}
		if ( 'deactivate' === $action ) {
			deactivate_plugins( $plugin );
			return array( 'plugin' => $plugin, 'active' => false );
		}
		return new WP_Error( 'cwpc_bad_arg', 'action must be "activate" or "deactivate".' );
	}

	/* ================================================================== */
	/*  SEO, meta & media                                                 */
	/* ================================================================== */

	public function set_seo( $args ) {
		$id = isset( $args['post_id'] ) ? (int) $args['post_id'] : 0;
		if ( ! get_post( $id ) ) {
			return new WP_Error( 'cwpc_not_found', 'Post not found.' );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to edit this post.' );
		}

		$updated = array();

		if ( isset( $args['focus_keyphrase'] ) ) {
			$kw = sanitize_text_field( $args['focus_keyphrase'] );
			update_post_meta( $id, '_yoast_wpseo_focuskw', $kw );
			update_post_meta( $id, 'rank_math_focus_keyword', $kw );
			$updated['focus_keyphrase'] = $kw;
		}
		if ( isset( $args['seo_title'] ) ) {
			$t = sanitize_text_field( $args['seo_title'] );
			update_post_meta( $id, '_yoast_wpseo_title', $t );
			update_post_meta( $id, 'rank_math_title', $t );
			$updated['seo_title'] = $t;
		}
		if ( isset( $args['meta_description'] ) ) {
			$d = sanitize_text_field( $args['meta_description'] );
			update_post_meta( $id, '_yoast_wpseo_metadesc', $d );
			update_post_meta( $id, 'rank_math_description', $d );
			$updated['meta_description'] = $d;
		}
		if ( isset( $args['canonical'] ) ) {
			$c = esc_url_raw( $args['canonical'] );
			update_post_meta( $id, '_yoast_wpseo_canonical', $c );
			update_post_meta( $id, 'rank_math_canonical_url', $c );
			$updated['canonical'] = $c;
		}

		if ( empty( $updated ) ) {
			return new WP_Error( 'cwpc_bad_arg', 'Provide at least one of: focus_keyphrase, seo_title, meta_description, canonical.' );
		}

		return array( 'post_id' => $id, 'updated' => $updated );
	}

	public function set_media_meta( $args ) {
		$id = isset( $args['id'] ) ? (int) $args['id'] : 0;
		$p  = get_post( $id );
		if ( ! $p || 'attachment' !== $p->post_type ) {
			return new WP_Error( 'cwpc_not_found', 'Attachment not found.' );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to edit this attachment.' );
		}

		$postarr = array( 'ID' => $id );
		if ( isset( $args['title'] ) ) {
			$postarr['post_title'] = sanitize_text_field( $args['title'] );
		}
		if ( isset( $args['caption'] ) ) {
			$postarr['post_excerpt'] = sanitize_text_field( $args['caption'] );
		}
		if ( isset( $args['description'] ) ) {
			$postarr['post_content'] = wp_kses_post( $args['description'] );
		}
		if ( count( $postarr ) > 1 ) {
			wp_update_post( $postarr );
		}
		if ( isset( $args['alt'] ) ) {
			update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( $args['alt'] ) );
		}

		return array( 'id' => $id, 'updated' => true );
	}

	public function set_featured_image( $args ) {
		$post_id = isset( $args['post_id'] ) ? (int) $args['post_id'] : 0;
		$att_id  = isset( $args['attachment_id'] ) ? (int) $args['attachment_id'] : 0;
		if ( ! get_post( $post_id ) ) {
			return new WP_Error( 'cwpc_not_found', 'Post not found.' );
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to edit this post.' );
		}
		if ( 'attachment' !== get_post_type( $att_id ) ) {
			return new WP_Error( 'cwpc_bad_arg', 'attachment_id is not a valid media item.' );
		}
		set_post_thumbnail( $post_id, $att_id );
		return array( 'post_id' => $post_id, 'attachment_id' => $att_id, 'set' => true );
	}

	public function set_comment_status( $args ) {
		$id = isset( $args['post_id'] ) ? (int) $args['post_id'] : 0;
		if ( ! get_post( $id ) ) {
			return new WP_Error( 'cwpc_not_found', 'Post not found.' );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to edit this post.' );
		}
		$status  = ( isset( $args['status'] ) && 'open' === $args['status'] ) ? 'open' : 'closed';
		$postarr = array( 'ID' => $id, 'comment_status' => $status );
		if ( isset( $args['ping_status'] ) ) {
			$postarr['ping_status'] = ( 'open' === $args['ping_status'] ) ? 'open' : 'closed';
		}
		wp_update_post( $postarr );
		return array( 'post_id' => $id, 'comment_status' => $status );
	}

	public function get_post_meta_tool( $args ) {
		$id = isset( $args['post_id'] ) ? (int) $args['post_id'] : 0;
		if ( ! get_post( $id ) ) {
			return new WP_Error( 'cwpc_not_found', 'Post not found.' );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to view this post.' );
		}
		$key = isset( $args['key'] ) ? sanitize_text_field( $args['key'] ) : '';
		if ( '' !== $key ) {
			return array( 'post_id' => $id, 'key' => $key, 'value' => get_post_meta( $id, $key, true ) );
		}
		return array( 'post_id' => $id, 'meta' => $this->safe_meta( $id ) );
	}

	public function set_post_meta_tool( $args ) {
		$gate = $this->require_dangerous();
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}
		$id = isset( $args['post_id'] ) ? (int) $args['post_id'] : 0;
		if ( ! get_post( $id ) ) {
			return new WP_Error( 'cwpc_not_found', 'Post not found.' );
		}
		$key = isset( $args['key'] ) ? sanitize_text_field( $args['key'] ) : '';
		if ( '' === $key ) {
			return new WP_Error( 'cwpc_bad_arg', 'A meta key is required.' );
		}
		$value = isset( $args['value'] ) ? $args['value'] : '';
		update_post_meta( $id, $key, $value );
		return array( 'post_id' => $id, 'key' => $key, 'updated' => true );
	}

	/* ================================================================== */
	/*  Plugins & themes (gated by "Enable dangerous tools")              */
	/* ================================================================== */

	private function load_upgrader() {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-ajax-upgrader-skin.php';
	}

	private function init_fs() {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		if ( function_exists( 'WP_Filesystem' ) ) {
			WP_Filesystem();
		}
	}

	public function install_plugin( $args ) {
		$gate = $this->require_dangerous();
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}
		if ( ! current_user_can( 'install_plugins' ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to install plugins.' );
		}
		$slug = isset( $args['slug'] ) ? sanitize_key( $args['slug'] ) : '';
		if ( '' === $slug ) {
			return new WP_Error( 'cwpc_bad_arg', 'A plugin slug is required (e.g. "wordpress-seo").' );
		}
		$this->load_upgrader();
		require_once ABSPATH . 'wp-admin/includes/plugin-install.php';

		$api = plugins_api( 'plugin_information', array( 'slug' => $slug, 'fields' => array( 'sections' => false ) ) );
		if ( is_wp_error( $api ) ) {
			return $api;
		}
		$skin     = new WP_Ajax_Upgrader_Skin();
		$upgrader = new Plugin_Upgrader( $skin );
		$result   = $upgrader->install( $api->download_link );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		if ( is_wp_error( $skin->result ) ) {
			return $skin->result;
		}
		if ( ! $result ) {
			$msgs = $skin->get_errors()->get_error_messages();
			return new WP_Error( 'cwpc_install_failed', $msgs ? implode( '; ', $msgs ) : 'Plugin install failed.' );
		}
		$plugin_file = $upgrader->plugin_info();
		$activated   = false;
		if ( ! empty( $args['activate'] ) && $plugin_file ) {
			$act       = activate_plugin( $plugin_file );
			$activated = ! is_wp_error( $act );
		}
		return array(
			'slug'      => $slug,
			'installed' => true,
			'plugin'    => $plugin_file,
			'activated' => $activated,
			'name'      => isset( $api->name ) ? $api->name : $slug,
			'version'   => isset( $api->version ) ? $api->version : '',
		);
	}

	public function update_plugin( $args ) {
		$gate = $this->require_dangerous();
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}
		if ( ! current_user_can( 'update_plugins' ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to update plugins.' );
		}
		$plugin = isset( $args['plugin'] ) ? sanitize_text_field( $args['plugin'] ) : '';
		if ( '' === $plugin ) {
			return new WP_Error( 'cwpc_bad_arg', 'A plugin file path is required (e.g. "wordpress-seo/wp-seo.php").' );
		}
		$this->load_upgrader();
		wp_update_plugins();
		$skin     = new WP_Ajax_Upgrader_Skin();
		$upgrader = new Plugin_Upgrader( $skin );
		$upgrader->upgrade( $plugin );
		if ( is_wp_error( $skin->result ) ) {
			return $skin->result;
		}
		return array( 'plugin' => $plugin, 'updated' => true );
	}

	public function delete_plugin( $args ) {
		$gate = $this->require_dangerous();
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}
		if ( ! current_user_can( 'delete_plugins' ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to delete plugins.' );
		}
		$plugin = isset( $args['plugin'] ) ? sanitize_text_field( $args['plugin'] ) : '';
		if ( '' === $plugin ) {
			return new WP_Error( 'cwpc_bad_arg', 'A plugin file path is required.' );
		}
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$this->init_fs();
		if ( is_plugin_active( $plugin ) ) {
			deactivate_plugins( $plugin );
		}
		$result = delete_plugins( array( $plugin ) );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return array( 'plugin' => $plugin, 'deleted' => (bool) $result );
	}

	public function list_themes( $args ) {
		$gate = $this->require_dangerous();
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}
		$active = wp_get_theme();
		$out    = array();
		foreach ( wp_get_themes() as $stylesheet => $theme ) {
			$out[] = array(
				'stylesheet' => $stylesheet,
				'name'       => $theme->get( 'Name' ),
				'version'    => $theme->get( 'Version' ),
				'active'     => ( $stylesheet === $active->get_stylesheet() ),
			);
		}
		return $out;
	}

	public function install_theme( $args ) {
		$gate = $this->require_dangerous();
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}
		if ( ! current_user_can( 'install_themes' ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to install themes.' );
		}
		$slug = isset( $args['slug'] ) ? sanitize_key( $args['slug'] ) : '';
		if ( '' === $slug ) {
			return new WP_Error( 'cwpc_bad_arg', 'A theme slug is required (e.g. "astra").' );
		}
		$this->load_upgrader();
		require_once ABSPATH . 'wp-admin/includes/theme.php';
		require_once ABSPATH . 'wp-admin/includes/theme-install.php';

		$api = themes_api( 'theme_information', array( 'slug' => $slug, 'fields' => array( 'sections' => false ) ) );
		if ( is_wp_error( $api ) ) {
			return $api;
		}
		$skin     = new WP_Ajax_Upgrader_Skin();
		$upgrader = new Theme_Upgrader( $skin );
		$result   = $upgrader->install( $api->download_link );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		if ( is_wp_error( $skin->result ) ) {
			return $skin->result;
		}
		if ( ! $result ) {
			$msgs = $skin->get_errors()->get_error_messages();
			return new WP_Error( 'cwpc_install_failed', $msgs ? implode( '; ', $msgs ) : 'Theme install failed.' );
		}
		$activated = false;
		if ( ! empty( $args['activate'] ) ) {
			switch_theme( $slug );
			$activated = true;
		}
		return array( 'slug' => $slug, 'installed' => true, 'activated' => $activated );
	}

	public function activate_theme( $args ) {
		$gate = $this->require_dangerous();
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}
		if ( ! current_user_can( 'switch_themes' ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to switch themes.' );
		}
		$stylesheet = isset( $args['stylesheet'] ) ? sanitize_text_field( $args['stylesheet'] ) : '';
		$theme      = wp_get_theme( $stylesheet );
		if ( ! $theme->exists() ) {
			return new WP_Error( 'cwpc_not_found', 'Theme not found: ' . $stylesheet );
		}
		switch_theme( $stylesheet );
		return array( 'stylesheet' => $stylesheet, 'active' => true );
	}

	public function delete_theme( $args ) {
		$gate = $this->require_dangerous();
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}
		if ( ! current_user_can( 'delete_themes' ) ) {
			return new WP_Error( 'cwpc_cap', 'You do not have permission to delete themes.' );
		}
		$stylesheet = isset( $args['stylesheet'] ) ? sanitize_text_field( $args['stylesheet'] ) : '';
		if ( '' === $stylesheet ) {
			return new WP_Error( 'cwpc_bad_arg', 'A theme stylesheet is required.' );
		}
		if ( $stylesheet === get_stylesheet() ) {
			return new WP_Error( 'cwpc_bad_arg', 'Cannot delete the active theme. Switch to another theme first.' );
		}
		$this->init_fs();
		require_once ABSPATH . 'wp-admin/includes/theme.php';
		$result = delete_theme( $stylesheet );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return array( 'stylesheet' => $stylesheet, 'deleted' => (bool) $result );
	}

	/* ================================================================== */
	/*  REST passthrough (gated by "Enable dangerous tools")              */
	/* ================================================================== */

	/**
	 * List every REST route registered on this site (core + active plugins/themes).
	 *
	 * @param array $args Optional { namespace, search }.
	 * @return array|WP_Error
	 */
	public function rest_discover( $args ) {
		$gate = $this->require_dangerous();
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}

		$server     = rest_get_server();
		$all_routes = $server->get_routes();
		$ns_filter  = isset( $args['namespace'] ) ? trim( (string) $args['namespace'], '/' ) : '';
		$search     = isset( $args['search'] ) ? (string) $args['search'] : '';
		$out        = array();

		foreach ( $all_routes as $route => $handlers ) {
			if ( '' !== $search && false === strpos( $route, $search ) ) {
				continue;
			}
			if ( '' !== $ns_filter && 0 !== strpos( ltrim( $route, '/' ), $ns_filter ) ) {
				continue;
			}

			$methods = array();
			foreach ( $handlers as $handler ) {
				if ( empty( $handler['methods'] ) ) {
					continue;
				}
				foreach ( (array) $handler['methods'] as $m => $enabled ) {
					if ( $enabled ) {
						$methods[ $m ] = true;
					}
				}
			}

			$out[] = array(
				'route'   => $route,
				'methods' => array_keys( $methods ),
			);
		}

		$namespaces = method_exists( $server, 'get_namespaces' ) ? $server->get_namespaces() : array();

		return array(
			'site'       => home_url( '/' ),
			'namespaces' => array_values( $namespaces ),
			'count'      => count( $out ),
			'routes'     => $out,
		);
	}

	/**
	 * Invoke any registered REST route internally and return status + data.
	 *
	 * Dispatched via rest_do_request(), so the target route runs its OWN
	 * permission_callback — this never bypasses a route's security, it only
	 * lets the authenticated administrator invoke it programmatically.
	 *
	 * @param array $args { method, route, query, body }.
	 * @return array|WP_Error
	 */
	public function rest_call( $args ) {
		$gate = $this->require_dangerous();
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}

		$method = isset( $args['method'] ) ? strtoupper( sanitize_text_field( $args['method'] ) ) : 'GET';
		$route  = isset( $args['route'] ) ? '/' . ltrim( (string) $args['route'], '/' ) : '';

		if ( '' === $route || '/' === $route ) {
			return new WP_Error( 'cwpc_bad_arg', 'A target "route" is required, e.g. "/wp/v2/posts".' );
		}
		if ( ! in_array( $method, array( 'GET', 'POST', 'PUT', 'PATCH', 'DELETE' ), true ) ) {
			return new WP_Error( 'cwpc_bad_arg', 'method must be one of: GET, POST, PUT, PATCH, DELETE.' );
		}
		// Never call the connector's own MCP endpoint through the passthrough.
		if ( false !== strpos( $route, CWPC_NAMESPACE ) ) {
			return new WP_Error( 'cwpc_self_call', 'Refusing to call the connector endpoint through itself.' );
		}

		// Accept query/body as objects or JSON strings.
		$query = ( isset( $args['query'] ) && is_array( $args['query'] ) ) ? $args['query'] : array();
		$body  = ( isset( $args['body'] ) && is_array( $args['body'] ) ) ? $args['body'] : array();
		if ( isset( $args['query'] ) && is_string( $args['query'] ) && '' !== $args['query'] ) {
			$decoded = json_decode( $args['query'], true );
			if ( is_array( $decoded ) ) {
				$query = $decoded;
			}
		}
		if ( isset( $args['body'] ) && is_string( $args['body'] ) && '' !== $args['body'] ) {
			$decoded = json_decode( $args['body'], true );
			if ( is_array( $decoded ) ) {
				$body = $decoded;
			}
		}

		$inner = new WP_REST_Request( $method, $route );
		if ( ! empty( $query ) ) {
			$inner->set_query_params( $query );
		}
		if ( ! empty( $body ) ) {
			$inner->set_body_params( $body );
			$inner->set_header( 'Content-Type', 'application/json' );
			$inner->set_body( wp_json_encode( $body ) );
		}

		/**
		 * Fires before a passthrough dispatch (handy for audit logging).
		 */
		do_action( 'cwpc_rest_before_call', $method, $route, $query, $body );

		$server   = rest_get_server();
		$response = rest_do_request( $inner );
		$status   = $response->get_status();
		$data     = $server->response_to_data( $response, false );

		return array(
			'requested' => array(
				'method' => $method,
				'route'  => $route,
			),
			'status'    => $status,
			'data'      => $data,
		);
	}

	/* ================================================================== */
	/*  Helpers                                                           */
	/* ================================================================== */

	/**
	 * Return post meta, skipping large/internal builder blobs to keep output sane.
	 */
	private function safe_meta( $id ) {
		$meta = get_post_meta( $id );
		$skip = array( '_elementor_data', '_elementor_css', '_fl_builder_data', '_fl_builder_draft', '_edit_lock', '_edit_last' );
		$out  = array();
		foreach ( $meta as $key => $val ) {
			if ( in_array( $key, $skip, true ) ) {
				$out[ $key ] = '[omitted: use cwpc_get_builder_content]';
				continue;
			}
			$out[ $key ] = ( is_array( $val ) && 1 === count( $val ) ) ? maybe_unserialize( $val[0] ) : $val;
		}
		return $out;
	}
}
