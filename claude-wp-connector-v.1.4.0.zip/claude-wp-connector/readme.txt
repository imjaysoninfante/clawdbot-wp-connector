=== Claude WP Connector ===
Contributors: jayson
Tags: mcp, claude, ai, page builder, elementor, divi, beaver builder
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connect your self-hosted WordPress site to Claude (or any MCP client) with administrator-level control over content, media, taxonomies, and page builders.

== Description ==

Claude WP Connector turns your WordPress site into a Model Context Protocol (MCP) server. Once connected, Claude can act like an administrator: list and edit posts and pages, upload media, manage categories and tags, read and update page-builder layouts (Elementor, Divi, Beaver Builder, Gutenberg), read your debug log to find errors, and — if you opt in — manage users, options, and plugins.

Everything runs through a single authenticated endpoint. The AI never has more power than the WordPress user it connects as.

= Available tools =

Content: cwpc_list_posts, cwpc_get_post, cwpc_create_post, cwpc_update_post, cwpc_delete_post
Media: cwpc_list_media, cwpc_upload_media, cwpc_upload_media_base64, cwpc_set_media_meta, cwpc_set_featured_image
Taxonomies: cwpc_list_terms, cwpc_create_term, cwpc_set_post_terms
Page builders: cwpc_detect_builder, cwpc_get_builder_content, cwpc_update_builder_content
Diagnostics: cwpc_site_info, cwpc_get_debug_log
Administrator (opt-in): cwpc_list_users, cwpc_get_option, cwpc_update_option, cwpc_list_plugins, cwpc_manage_plugin

== Installation ==

1. In wp-admin, go to Plugins > Add New > Upload Plugin and upload the ZIP.
2. Activate it.
3. Go to Settings > Claude Connector, click "Generate token", and copy the MCP endpoint URL and token.
4. Connect Claude (see INSTALL-AND-CONNECT.md).

== Security ==

* Use HTTPS. The token is a full-access credential.
* Keep "Enable dangerous tools" off unless you need user/plugin/option management.
* Remove the plugin if you stop using the connection.

== Changelog ==

= 1.2.0 =
* New tool: cwpc_upload_media_base64 — upload files to the media library directly from base64-encoded bytes, with no public URL required. Useful for images generated on the fly. Supports optional title, alt, caption, description, attach_to, and set_featured, and validates file type and user capability.

= 1.1.0 =
* Added SEO and meta tools (cwpc_set_seo, cwpc_set_media_meta, cwpc_set_featured_image, cwpc_set_comment_status, cwpc_get_post_meta, cwpc_set_post_meta) and plugin/theme management tools.

= 1.0.0 =
* Initial release: MCP endpoint, content/media/taxonomy tools, page-builder read/write, admin tools, debug log reader.
