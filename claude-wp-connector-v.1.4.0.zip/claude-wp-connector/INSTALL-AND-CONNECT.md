# Claude WP Connector — Install & Connect

This plugin exposes your self-hosted WordPress site to Claude as an MCP server, giving Claude administrator-level control over posts, pages, media, taxonomies, and page builders (Elementor, Divi, Beaver Builder, Gutenberg).

---

## 1. Install the plugin

1. Zip is already built: `claude-wp-connector.zip`.
2. In your site: **wp-admin → Plugins → Add New → Upload Plugin**.
3. Choose the zip, click **Install Now**, then **Activate**.
4. Go to **Settings → Claude Connector**.
5. Click **Generate token**. Copy two things:
   - **MCP endpoint URL** — looks like `https://yoursite.com/wp-json/claude-connector/v1/mcp`
   - **Bearer token** — a long random string.
6. (Optional) Set **Act as user** to your admin account, and tick **Enable dangerous tools** only if you want Claude to manage users/plugins/options.

Confirm it's live by visiting `https://yoursite.com/wp-json/claude-connector/v1/ping` in a browser — you should see a small JSON response.

---

## 2. Connect it to Claude

Recommended protocol: **MCP over Streamable HTTP**, authenticated with your bearer token.
Because self-hosted WordPress has no OAuth, connect through the `mcp-remote` bridge, which passes your token as a header. This works in Claude Desktop and Claude Code.

### Option A — Claude Desktop (easiest)

1. Install Node.js (https://nodejs.org) if you don't have it.
2. Open Claude Desktop → **Settings → Developer → Edit Config**. This opens `claude_desktop_config.json`.
3. Add this (replace the URL and token):

```json
{
  "mcpServers": {
    "wordpress": {
      "command": "npx",
      "args": [
        "-y",
        "mcp-remote",
        "https://yoursite.com/wp-json/claude-connector/v1/mcp",
        "--header",
        "Authorization: Bearer YOUR_TOKEN_HERE"
      ]
    }
  }
}
```

4. Save and fully restart Claude Desktop.
5. In a new chat, click the tools/connector icon — you should see the WordPress tools. Try: *"List my 5 most recent posts."*

### Option B — Claude Code (CLI)

```bash
claude mcp add wordpress -- npx -y mcp-remote \
  https://yoursite.com/wp-json/claude-connector/v1/mcp \
  --header "Authorization: Bearer YOUR_TOKEN_HERE"
```

### Option C — Direct custom connector (claude.ai)

If you're using the web app's custom connector feature, add the MCP endpoint URL directly. When it asks for authentication, supply the token as a Bearer header. If the connector UI only supports OAuth, use Option A or B instead — the `mcp-remote` bridge is the reliable path for self-hosted sites today.

### Alternative auth: Application Passwords (no token)

Instead of the plugin token you can authenticate as any admin using a WordPress **Application Password**:

1. **wp-admin → Users → Profile → Application Passwords** → create one, copy it.
2. Use it as HTTP Basic auth. With `mcp-remote`:

```
"--header", "Authorization: Basic <base64 of username:app_password>"
```

The plugin token is simpler; Application Passwords are handy if you want per-user revocation.

---

## 3. What you can ask Claude to do

- "Find posts mentioning 'pricing' and fix the broken heading on the pricing page."
- "This page uses Elementor — pull its content, make the hero headline bigger, and save it."
- "Create a draft page called 'About' with these three sections."
- "Upload this image URL and set it as the featured image on post 42."
- "Read the debug log and tell me what's throwing errors."
- "Add the tags 'guide' and 'wordpress' to post 108."

Claude auto-detects the builder per page and edits the right data (Elementor JSON, Divi shortcodes, Beaver Builder data, or Gutenberg blocks).

---

## 4. Safety notes

- **Use HTTPS.** The token is a full-access credential — treat it like a password.
- Elementor/Beaver edits change stored builder data. Consider a backup plugin, or duplicate a page before large edits.
- After an Elementor edit, if styles look stale, open the page in the Elementor editor once (or clear Elementor's cache) to regenerate CSS.
- Keep **"Enable dangerous tools"** off unless you specifically need user/plugin/option management.
- To revoke access instantly: regenerate the token (breaks the old connection) or deactivate the plugin.

---

## 5. Extending it

Add a new capability by adding a method in `includes/class-cwpc-tools.php`, registering it in `map()`, and adding its schema in `definitions()`. The MCP server and auth layer need no changes.
