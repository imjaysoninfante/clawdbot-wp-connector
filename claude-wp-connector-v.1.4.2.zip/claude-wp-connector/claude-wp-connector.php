<?php
/**
 * Plugin Name:       Claude WP Connector
 * Plugin URI:        https://example.com/claude-wp-connector
 * Description:        Exposes your WordPress site to Claude (and any MCP client) with administrator-level control: posts, pages, media, taxonomies, and page builders (Elementor, Divi, Beaver Builder). Secured with a bearer token or WordPress Application Passwords.
 * Version:           1.4.2
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Jayson
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       claude-wp-connector
 *
 * SECURITY NOTE: This plugin grants a connected AI client the same power as a
 * WordPress administrator. Keep the token secret, serve your site over HTTPS,
 * and remove the plugin if you stop using it.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'CWPC_VERSION', '1.4.2' );
define( 'CWPC_PLUGIN_FILE', __FILE__ );
define( 'CWPC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CWPC_NAMESPACE', 'claude-connector/v1' );

require_once CWPC_PLUGIN_DIR . 'includes/class-cwpc-auth.php';
require_once CWPC_PLUGIN_DIR . 'includes/class-cwpc-tools.php';
require_once CWPC_PLUGIN_DIR . 'includes/class-cwpc-mcp-server.php';

/**
 * Main plugin controller.
 */
final class CWPC_Plugin {

	/** @var CWPC_Plugin */
	private static $instance;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	/**
	 * Register the MCP endpoint and a simple health-check route.
	 */
	public function register_routes() {
		$server = new CWPC_MCP_Server();

		// Primary MCP (JSON-RPC) endpoint.
		register_rest_route(
			CWPC_NAMESPACE,
			'/mcp',
			array(
				'methods'             => 'POST',
				'callback'            => array( $server, 'handle' ),
				'permission_callback' => array( 'CWPC_Auth', 'check' ),
			)
		);

		// Unauthenticated health check so you can confirm the plugin is live.
		register_rest_route(
			CWPC_NAMESPACE,
			'/ping',
			array(
				'methods'             => 'GET',
				'callback'            => function () {
					return array(
						'ok'      => true,
						'plugin'  => 'Claude WP Connector',
						'version' => CWPC_VERSION,
						'site'    => get_bloginfo( 'name' ),
					);
				},
				'permission_callback' => '__return_true',
			)
		);
	}

	/* ------------------------------------------------------------------ */
	/*  Admin settings page                                               */
	/* ------------------------------------------------------------------ */

	public function admin_menu() {
		add_options_page(
			__( 'Claude WP Connector', 'claude-wp-connector' ),
			__( 'Claude Connector', 'claude-wp-connector' ),
			'manage_options',
			'claude-wp-connector',
			array( $this, 'render_settings_page' )
		);
	}

	public function register_settings() {
		register_setting( 'cwpc_settings', 'cwpc_token', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting(
			'cwpc_settings',
			'cwpc_admin_user',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 0,
			)
		);
		register_setting(
			'cwpc_settings',
			'cwpc_allow_dangerous',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 0,
			)
		);
	}

	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Generate a token on demand.
		if ( isset( $_POST['cwpc_generate_token'] ) && check_admin_referer( 'cwpc_generate_token' ) ) {
			update_option( 'cwpc_token', wp_generate_password( 48, false, false ) );
			echo '<div class="notice notice-success"><p>' . esc_html__( 'A new token was generated.', 'claude-wp-connector' ) . '</p></div>';
		}

		$token      = get_option( 'cwpc_token', '' );
		$admin_user = (int) get_option( 'cwpc_admin_user', get_current_user_id() );
		$endpoint   = rest_url( CWPC_NAMESPACE . '/mcp' );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Claude WP Connector', 'claude-wp-connector' ); ?></h1>
			<p><?php esc_html_e( 'Connect this site to Claude (or any MCP client) with administrator-level control.', 'claude-wp-connector' ); ?></p>

			<h2><?php esc_html_e( 'Your connection details', 'claude-wp-connector' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'MCP endpoint URL', 'claude-wp-connector' ); ?></th>
					<td><code><?php echo esc_html( $endpoint ); ?></code></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Bearer token', 'claude-wp-connector' ); ?></th>
					<td>
						<code style="word-break:break-all;"><?php echo $token ? esc_html( $token ) : esc_html__( '(none yet - generate one below)', 'claude-wp-connector' ); ?></code>
						<form method="post" style="margin-top:8px;">
							<?php wp_nonce_field( 'cwpc_generate_token' ); ?>
							<button type="submit" name="cwpc_generate_token" class="button button-secondary">
								<?php echo $token ? esc_html__( 'Regenerate token', 'claude-wp-connector' ) : esc_html__( 'Generate token', 'claude-wp-connector' ); ?>
							</button>
						</form>
						<p class="description"><?php esc_html_e( 'Send this as an HTTP header "Authorization: Bearer <token>" or as a ?token= query parameter.', 'claude-wp-connector' ); ?></p>
					</td>
				</tr>
			</table>

			<form method="post" action="options.php">
				<?php settings_fields( 'cwpc_settings' ); ?>
				<h2><?php esc_html_e( 'Settings', 'claude-wp-connector' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="cwpc_admin_user"><?php esc_html_e( 'Act as user', 'claude-wp-connector' ); ?></label></th>
						<td>
							<?php
							wp_dropdown_users(
								array(
									'name'     => 'cwpc_admin_user',
									'id'       => 'cwpc_admin_user',
									'selected' => $admin_user,
									'role'     => 'administrator',
								)
							);
							?>
							<p class="description"><?php esc_html_e( 'When a request authenticates with the bearer token, the plugin acts as this administrator.', 'claude-wp-connector' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Enable dangerous tools', 'claude-wp-connector' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="cwpc_allow_dangerous" value="1" <?php checked( 1, (int) get_option( 'cwpc_allow_dangerous', 0 ) ); ?> />
								<?php esc_html_e( 'Allow user management, plugin activation/deactivation, and option editing.', 'claude-wp-connector' ); ?>
							</label>
							<p class="description"><?php esc_html_e( 'Leave off unless you need it. Content and page-builder tools work regardless.', 'claude-wp-connector' ); ?></p>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}

CWPC_Plugin::instance();

/* ====================================================================== */
/*  All-in-One WP Migration backup endpoints                              */
/*                                                                        */
/*  Drives AIO WPM's own export pipeline (the `ai1wm_export` filter) to   */
/*  produce a single .wpress backup in wp-content/ai1wm-backups. A lock   */
/*  guarantees only one backup runs at a time, so each run = one file.    */
/*                                                                        */
/*  Reach these via the connector's cwpc_rest_call passthrough:           */
/*    POST /wp-json/cowork/v1/ai1wm-backup         -> start ONE backup    */
/*    GET  /wp-json/cowork/v1/ai1wm-backup/status  -> running? + newest   */
/*    GET  /wp-json/cowork/v1/ai1wm-backups        -> list .wpress files  */
/* ====================================================================== */

if ( ! defined( 'COWORK_AI1WM_LOCK' ) ) {
	define( 'COWORK_AI1WM_LOCK', 'cowork_ai1wm_lock' );
}

add_action( 'rest_api_init', function () {

	$cowork_ai1wm_auth = function () {
		return current_user_can( 'export' ) || current_user_can( 'manage_options' );
	};

	register_rest_route( 'cowork/v1', '/ai1wm-backup', array(
		'methods'             => 'POST',
		'permission_callback' => $cowork_ai1wm_auth,
		'callback'            => 'cowork_ai1wm_backup_start',
	) );

	register_rest_route( 'cowork/v1', '/ai1wm-backup/status', array(
		'methods'             => 'GET',
		'permission_callback' => $cowork_ai1wm_auth,
		'callback'            => 'cowork_ai1wm_backup_status',
	) );

	register_rest_route( 'cowork/v1', '/ai1wm-backups', array(
		'methods'             => 'GET',
		'permission_callback' => $cowork_ai1wm_auth,
		'callback'            => 'cowork_ai1wm_list_backups',
	) );
} );

/**
 * Start and run ONE full export to completion. If the HTTP client disconnects,
 * ignore_user_abort() keeps it running server-side until the .wpress is finished.
 */
if ( ! function_exists( 'cowork_ai1wm_backup_start' ) ) {
	function cowork_ai1wm_backup_start( $request ) {
		global $wp_filter;

		if ( ! defined( 'AI1WM_SECRET_KEY' ) || ! function_exists( 'ai1wm_setup_environment' ) || ! defined( 'AI1WM_BACKUPS_PATH' ) ) {
			return new WP_Error( 'ai1wm_missing', 'All-in-One WP Migration is not active.', array( 'status' => 500 ) );
		}

		$lock = get_transient( COWORK_AI1WM_LOCK );
		if ( is_array( $lock ) ) {
			return new WP_REST_Response( array(
				'started' => false,
				'running' => true,
				'message' => 'A backup is already running. Poll /ai1wm-backup/status.',
				'lock'    => $lock,
			), 409 );
		}

		ai1wm_setup_environment(); // set_time_limit(0), ignore_user_abort(true)

		$params = array(
			'secret_key' => get_option( AI1WM_SECRET_KEY ),
			'options'    => array(), // full backup, no exclusions
			'priority'   => 5,
		);

		if ( ! isset( $wp_filter['ai1wm_export'] ) ) {
			return new WP_Error( 'ai1wm_no_hook', 'ai1wm_export pipeline not registered.', array( 'status' => 500 ) );
		}
		$hooks = $wp_filter['ai1wm_export'];
		if ( isset( $hooks->callbacks ) ) {
			$hooks = $hooks->callbacks;
		}
		ksort( $hooks );

		$started_at = current_time( 'mysql' );
		set_transient( COWORK_AI1WM_LOCK, array( 'started_at' => $started_at, 'archive' => null ), HOUR_IN_SECONDS );

		foreach ( array_keys( $hooks ) as $priority ) {
			$params['priority'] = $priority;
			while ( true ) {
				foreach ( $hooks[ $priority ] as $hook ) {
					$params = call_user_func_array( $hook['function'], array( $params ) );
				}
				$completed = isset( $params['completed'] ) ? (bool) $params['completed'] : true;

				if ( ! empty( $params['archive'] ) ) {
					set_transient( COWORK_AI1WM_LOCK, array( 'started_at' => $started_at, 'archive' => $params['archive'] ), HOUR_IN_SECONDS );
				}

				if ( false === $completed ) {
					continue;
				}
				break;
			}
		}

		delete_transient( COWORK_AI1WM_LOCK );

		return cowork_ai1wm_backup_reply( $params );
	}
}

if ( ! function_exists( 'cowork_ai1wm_backup_status' ) ) {
	function cowork_ai1wm_backup_status() {
		$lock    = get_transient( COWORK_AI1WM_LOCK );
		$running = is_array( $lock );
		$latest  = null;

		if ( defined( 'AI1WM_BACKUPS_PATH' ) ) {
			$files = glob( AI1WM_BACKUPS_PATH . DIRECTORY_SEPARATOR . '*.wpress' );
			if ( $files ) {
				usort( $files, function ( $a, $b ) { return filemtime( $b ) - filemtime( $a ); } );
				$latest = array(
					'file'     => basename( $files[0] ),
					'size'     => size_format( filesize( $files[0] ) ),
					'bytes'    => filesize( $files[0] ),
					'modified' => date( 'Y-m-d H:i:s', filemtime( $files[0] ) ),
				);
			}
		}

		return new WP_REST_Response( array(
			'running'       => $running,
			'lock'          => $running ? $lock : null,
			'latest_backup' => $latest,
		), 200 );
	}
}

if ( ! function_exists( 'cowork_ai1wm_list_backups' ) ) {
	function cowork_ai1wm_list_backups() {
		if ( ! defined( 'AI1WM_BACKUPS_PATH' ) ) {
			return new WP_Error( 'ai1wm_missing', 'All-in-One WP Migration is not loaded.', array( 'status' => 500 ) );
		}
		$out = array();
		foreach ( glob( AI1WM_BACKUPS_PATH . DIRECTORY_SEPARATOR . '*.wpress' ) as $f ) {
			$out[] = array(
				'file'     => basename( $f ),
				'bytes'    => filesize( $f ),
				'size'     => size_format( filesize( $f ) ),
				'modified' => date( 'Y-m-d H:i:s', filemtime( $f ) ),
				'mtime'    => filemtime( $f ),
			);
		}
		usort( $out, function ( $a, $b ) { return $b['mtime'] - $a['mtime']; } );
		return new WP_REST_Response( array( 'count' => count( $out ), 'backups' => $out ), 200 );
	}
}

if ( ! function_exists( 'cowork_ai1wm_backup_reply' ) ) {
	function cowork_ai1wm_backup_reply( $params ) {
		$out = array( 'done' => true );
		if ( ! empty( $params['archive'] ) ) {
			$file           = AI1WM_BACKUPS_PATH . DIRECTORY_SEPARATOR . $params['archive'];
			$exists         = file_exists( $file );
			$out['archive'] = $params['archive'];
			$out['exists']  = $exists;
			$out['bytes']   = $exists ? filesize( $file ) : 0;
			$out['size']    = $exists ? size_format( filesize( $file ) ) : null;
		}
		return new WP_REST_Response( $out, 200 );
	}
}
